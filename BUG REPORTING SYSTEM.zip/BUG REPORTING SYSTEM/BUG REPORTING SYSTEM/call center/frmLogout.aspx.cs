﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Employee_frmLogout : System.Web.UI.Page
{
    clsCustomer objReqCust = new clsCustomer();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["UserId"] != null)
            {
                // clsEmployee.LogOffTime(DateTime.Now, Session["EmpId"].ToString(),Convert.ToInt32( Session["NoofClients"]));
                objReqCust.EmpId = Convert.ToInt32(Session["UserId"]);
                objReqCust.LoginDate = Convert.ToDateTime(Session["LoginDate"]);
                objReqCust.GetLogoutTime();
                Session.Abandon();
                FormsAuthentication.SignOut();
            }

        }
    }
    protected void lnkLogin_Click(object sender, EventArgs e)
    {
        Response.Redirect("/CallCenterManagement/Default.aspx");
    }
}
