﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Admin_frmCustomerMaster : System.Web.UI.Page
{
    clsCustomer objCust = new clsCustomer();
    protected void Page_Load(object sender, EventArgs e)
    {
        lblMsg.Text = "";
        //btnCloseGrid.Visible = false;
        if (!IsPostBack)
        { 
        
        }
    }
    void BindCustomers()
    {
        try
        {
            DataSet ds = objCust.GetAllCustomers();
            ViewState["Data"] = ds;

            if (ds.Tables[0].Rows.Count != 0)
            {
                ddlCustId.DataSource = ds;
                ddlCustId.DataValueField = "CustomerId";
                ddlCustId.DataTextField = "Cust_Name";
                ddlCustId.DataBind();
                ddlCustId.Items.Insert(0, "--Select Customer--");
            }
            else
            {
                lblMsg.Text = "No Records Found..";
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    void ClearData()
    {
        try
        {
            txtAddress.Text = "";
            txtEmail.Text = "";
            //txtExpDate.Text = "";
            txtName.Text = "";
            //txtRegdDate.Text = "";
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {

            if (RadioButtonList1.SelectedIndex == 0)
            {
                lblMsg.Text = "";
                //grdAllCustomers.Visible = false;
                //btnCloseGrid.Enabled = true;
                ClearData();

                txtName.Focus();
                btnSubmit.Text = "Submit new record";
                btnSubmit.Enabled = true;
                BindCustomers();
                if (ddlCustId.Items.Count != 0)
                    ddlCustId.SelectedIndex = 0;

                ddlCustId.Enabled = false;
                txtName.ReadOnly = false;
            }
            else if (RadioButtonList1.SelectedIndex == 1)
            {
                //grdAllCustomers.Visible = false;
                //btnCloseGrid.Visible = false;
                ClearData();
                BindCustomers();
                btnSubmit.Text = "Modify record";
                btnSubmit.Enabled = true;
                //txtName.ReadOnly = true;
                ddlCustId.Enabled = true;
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void ddlCustId_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlCustId.SelectedIndex != 0)
            {
                lblMsg.Text = "";
                ClearData();
                objCust.CustId = Convert.ToInt32(ddlCustId.SelectedItem.Value);
                DataSet ds = objCust.GetCustomerMasterDataByCustId();
                DataRow dr = ds.Tables[0].Rows[0];
                if (ds.Tables[0].Rows.Count != 0)
                {
                    txtName.Text = dr["Cust_Name"].ToString();
                    txtAddress.Text = dr["Cust_Address"].ToString();
                    txtEmail.Text = dr["Cust_Email"].ToString();
                    //txtRegdDate.Text = dr["Cust_RegdDate"].ToString();
                    //txtExpDate.Text = dr["Cust_RegdExpDate"].ToString();
                }
                else
                {
                    lblMsg.Text = "No Records Found..";
                }
            }


        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    //protected void btnShowAll_Click(object sender, EventArgs e)
    //{
    //    try
    //    {
    //        ClearData();
    //        if (ddlCustId.Items.Count != 0)
    //            ddlCustId.SelectedIndex = 0;
    //        lblMsg.Text = "";
    //        DataSet ds = (DataSet)ViewState["Data"];

    //        if (ds.Tables[0].Rows.Count != 0)
    //        {
    //            grdAllCustomers.DataSource = ds.Tables[0];
    //            grdAllCustomers.DataBind();
    //            grdAllCustomers.Visible = true;
    //            btnCloseGrid.Visible = true;
    //        }
    //        else
    //        {
    //            grdAllCustomers.EmptyDataText = "No Records Found..";
    //            grdAllCustomers.DataBind();
    //        }
    //        //pnlAllData.Visible = true;
    //    }
    //    catch (Exception ex)
    //    {
    //        //pnlAllData.Visible = false;
    //        lblMsg.Text = "Error:Contact System Admin" + ex.Message;
    //    }
    //}
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            if (RadioButtonList1.SelectedIndex == 0 && btnSubmit.Text == "Submit new record")
            {
                lblMsg.Text = "";
                
                txtName.Focus();
                objCust.CustName = txtName.Text;
                //objCust.RegdDate =Convert.ToDateTime( txtRegdDate.Text);
               // objCust.ExpDate =Convert.ToDateTime( txtExpDate.Text);
                objCust.Address = txtAddress.Text;
                objCust.Email = txtEmail.Text;                
                lblMsg.Text = objCust.InsertCustomerMaster();
                ClearData();
                BindCustomers();

            }
            else if (RadioButtonList1.SelectedIndex == 1 && btnSubmit.Text == "Modify record")
            {
                lblMsg.Text = "";
               
                objCust.CustId = Convert.ToInt32(ddlCustId.SelectedItem.Value);
                objCust.CustName = txtName.Text;
               // objCust.RegdDate =Convert.ToDateTime( txtRegdDate.Text);
                //objCust.ExpDate =Convert.ToDateTime( txtExpDate.Text);
                objCust.Address = txtAddress.Text;
                objCust.Email = txtEmail.Text;
                lblMsg.Text = objCust.UpdateCustomerMaster();
                ClearData();
                BindCustomers();
                ddlCustId.SelectedIndex = 0;
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        ClearData();
        if(ddlCustId.Items.Count !=0)
        ddlCustId.SelectedIndex = 0;
    }
    //protected void grdAllCustomers_PageIndexChanging(object sender, GridViewPageEventArgs e)
    //{
    //    try
    //    {
    //        DataSet ds = (DataSet)ViewState["Data"];
    //        if (ds.Tables[0].Rows.Count != 0)
    //        {
    //            grdAllCustomers.PageIndex = e.NewPageIndex;
    //            grdAllCustomers.DataSource = ds.Tables[0];
    //            grdAllCustomers.DataBind();
    //            grdAllCustomers.Visible = true;
    //            btnCloseGrid.Visible = true;
    //        }
    //        else
    //        {
    //            lblMsg.Text = "No Records Found..";
    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //        lblMsg.Text = ex.Message;
    //    }
    //}
    //protected void btnCloseGrid_Click(object sender, EventArgs e)
    //{
    //    try
    //    {
    //        lblMsg.Text = "";
    //        grdAllCustomers.Visible = false;            
    //        btnCloseGrid.Visible = false;
    //    }
    //    catch (Exception ex)
    //    {
    //        lblMsg.Text = ex.Message;
    //    }
    //}
}
