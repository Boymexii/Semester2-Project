﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Admin_frmHolidayMaster : System.Web.UI.Page
{
    int j;
    clsHoliday objHoliday = new clsHoliday();
    protected void Page_Load(object sender, EventArgs e)
    {
        lblMsg.Text = "";
        btnCloseGrid.Visible = false;
        if (!IsPostBack)
        { 
        
        }
    }
    void ClearData()
    {
        txtDate.Text = "";
        txtReason.Text = "";
        
    }
    void BindHolidayIds()
    {
        try
        {
            //lblMsg.Text = "";
            DataSet ds = objHoliday.GetAllHolidayIds();
            
            if (ds.Tables[0].Rows.Count != 0)
            {
                ddlHolidayId.DataSource = ds.Tables[0];
                ddlHolidayId.DataValueField = "HolidayId";
                ddlHolidayId.DataBind();
                ddlHolidayId.Items.Insert(0, "--Select Holiday--");
            }
            else
            {
                lblMsg.Text = "No Records Found..";
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    void BindScruitinizedEmp()
    {
        try
        {
            lblMsg.Text = "";
            DataSet ds = objHoliday.GetScruitinizedEmp();
            if (ds.Tables[0].Rows.Count != 0)
            {
                ddlScruitinized.DataSource = ds.Tables[0];
                ddlScruitinized.DataValueField = "EmpId";
                ddlScruitinized.DataTextField = "Emp_FirstName";
                ddlScruitinized.DataBind();
                ddlScruitinized.Items.Insert(0, "--Select Employee--");
            }
            else
            {
                lblMsg.Text = "No Records Found..";
                ddlScruitinized.Items.Insert(0, "--Select Employee--");
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }

    protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            lblMsg.Text = "";
            if (RadioButtonList1.SelectedIndex == 0)
            {
                //grdAllDepts.Visible = false;
                //btnCloseGrid.Enabled = false;
                ClearData();
                ddlScruitinized.Items.Clear();
                
                btnSubmit.Text = "Submit new record";
                btnSubmit.Enabled = true;
                 BindScruitinizedEmp();
                if (ddlHolidayId.Items.Count != 0)
                    ddlHolidayId.SelectedIndex = 0;
                if (ddlScruitinized.Items.Count != 0)
                    ddlScruitinized.SelectedIndex = 0;
                ddlHolidayId.Enabled = false;
                
            }
            else if (RadioButtonList1.SelectedIndex == 1)
            {
                ddlScruitinized.Items.Clear();
                grdAllHolidays.Visible = false;
                btnCloseGrid.Visible = false;
                ClearData();
                BindHolidayIds();
                // BindIncharges();
                btnSubmit.Text = "Modify record";
                btnSubmit.Enabled = true;
                //txtName.ReadOnly = true;
                ddlHolidayId.Enabled = true;
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void ddlHolidayId_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            lblMsg.Text = "";
            if (ddlHolidayId.SelectedIndex != 0)
            {
                grdAllHolidays.Visible = false;
                btnCloseGrid.Enabled = false;
                objHoliday.HolidayId = Convert.ToInt32(ddlHolidayId.SelectedItem.Value);
                BindScruitinizedEmp();
                DataSet ds = objHoliday.GetHolidayMasterDataByHolidayId();
                DataRow dr = ds.Tables[0].Rows[0];
                if (ds.Tables[0].Rows.Count != 0)
                {
                    txtDate.Text = dr["HolidayDate"].ToString();
                    txtReason.Text = dr["ReasonForHoliday"].ToString();
                    int InchargeId = Convert.ToInt32(dr["EmpScruitinizedId"]);
                    if (InchargeId > 0)
                    {
                        for (int i = 0; i < ddlScruitinized.Items.Count; i++)
                        {
                            if (ddlScruitinized.Items[i].Value == InchargeId.ToString())
                            {
                                j = i;
                            }
                            ddlScruitinized.Items[i].Selected = false;
                        }
                        ddlScruitinized.Items[j].Selected = true;
                    }
                    else
                    {
                        ddlScruitinized.SelectedIndex = 0;
                    }
                }
                else
                {
                    lblMsg.Text = "No data found for this DeptId..";

                }
            }
            else
            {
                ClearData();
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void btnShowAll_Click(object sender, EventArgs e)
    {
        try
        {
            ClearData();
            if (ddlHolidayId.Items.Count != 0)
                ddlHolidayId.SelectedIndex = 0;
            if (ddlScruitinized.Items.Count != 0)
                ddlScruitinized.SelectedIndex = 0;
            lblMsg.Text = "";
            DataSet ds = objHoliday.GetAllHolidayMasterData();
           ViewState["Data"]=ds;
            if (ds.Tables[1].Rows.Count != 0)
            {
                grdAllHolidays.DataSource = ds.Tables[1];
                grdAllHolidays.DataBind();
                grdAllHolidays.Visible = true;
                btnCloseGrid.Visible = true;
            }
            else
            {
                grdAllHolidays.EmptyDataText = "No Records Found..";
                grdAllHolidays.DataBind();
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = "Error:Contact System Admin" + ex.Message;
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {

            if (RadioButtonList1.SelectedIndex == 0 && btnSubmit.Text == "Submit new record")
            {
                lblMsg.Text = "";

                //txtDate.Focus();
                objHoliday.HolidayDate = Convert.ToDateTime( txtDate.Text);
                objHoliday.Reason = txtReason.Text;
                objHoliday.ScruitinizedEmp = Convert.ToInt32(ddlScruitinized.SelectedItem.Value);


                lblMsg.Text = objHoliday.InsertHolidayMaster();

                BindHolidayIds();

            }

            else if (RadioButtonList1.SelectedIndex == 1 && btnSubmit.Text == "Modify record")
            {
                lblMsg.Text = "";

                objHoliday.HolidayId = Convert.ToInt32(ddlHolidayId.SelectedItem.Value);
                objHoliday.HolidayDate = Convert.ToDateTime( txtDate.Text);
                objHoliday.Reason = txtReason.Text;
                objHoliday.ScruitinizedEmp = Convert.ToInt32(ddlScruitinized.SelectedItem.Value);


                lblMsg.Text = objHoliday.UpdateHolidayMaster();

                ddlHolidayId.SelectedIndex = 0;
            }
        }

        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        if (RadioButtonList1.SelectedIndex == 0)
        {
            ClearData();
            //txtName.Focus();
            lblMsg.Text = "";
        }
        else
        {
            ClearData();
            if(ddlHolidayId.Items.Count !=0)
            ddlHolidayId.SelectedIndex = 0;
            if(ddlScruitinized.Items.Count !=0)
            ddlScruitinized.Items.Clear();
            lblMsg.Text = "";
        }
    }
    protected void btnCloseGrid_Click(object sender, EventArgs e)
    {
        try
        {
            lblMsg.Text = "";
            grdAllHolidays.Visible = false;
            btnCloseGrid.Visible = false;
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void grdAllHolidays_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            DataSet ds = (DataSet)ViewState["Data"];
            if (ds.Tables[1].Rows.Count > 0)
            {
                grdAllHolidays.PageIndex=e.NewPageIndex;
                grdAllHolidays.DataSource = ds.Tables[1];
                grdAllHolidays.DataBind();
                grdAllHolidays.Visible = true;
                btnCloseGrid.Visible = true;
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
}
