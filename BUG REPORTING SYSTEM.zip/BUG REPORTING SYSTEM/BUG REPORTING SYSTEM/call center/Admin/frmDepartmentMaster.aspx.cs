﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Admin_frmDepartmentMaster : System.Web.UI.Page
{
    clsEmployee objDept = new clsEmployee();
    int j;
    protected void Page_Load(object sender, EventArgs e)
    {
        lblMsg.Text = "";
        btnCloseGrid.Visible = false;
        if (!IsPostBack)
        {
            
        }
    }
    protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            lblMsg.Text = "";
            if (RadioButtonList1.SelectedIndex == 0)
            {
                //grdAllDepts.Visible = false;
                //btnCloseGrid.Enabled = false;
                ClearData();
                ddlIncharge.Items.Clear();
                txtName.Focus();
                btnSubmit.Text = "Submit new record";
                btnSubmit.Enabled = true;
               // BindIncharges();
                if(ddlDeptId.Items.Count !=0)
                ddlDeptId.SelectedIndex = 0;
                if (ddlIncharge.Items.Count != 0)
                    ddlIncharge.SelectedIndex = 0;
                ddlDeptId.Enabled = false;
                txtName.ReadOnly = false;
            }
            else if (RadioButtonList1.SelectedIndex == 1)
            {
                ddlIncharge.Items.Clear();
                grdAllDepts.Visible = false;
                btnCloseGrid.Visible = false;
                ClearData();
                BindDeptIds();
                BindIncharges();
                btnSubmit.Text = "Modify record";
                btnSubmit.Enabled = true;
                //txtName.ReadOnly = true;
                ddlDeptId.Enabled = true;
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void ddlDeptId_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            lblMsg.Text = "";
            if (ddlDeptId.SelectedIndex != 0)
            {
                ddlIncharge.Items.Clear();
                grdAllDepts.Visible = false;
                btnCloseGrid.Enabled = false;
                objDept.DeptId = Convert.ToInt32(ddlDeptId.SelectedItem.Value);
                BindIncharges();
                DataSet ds = objDept.GetDeptMasterDataByDeptId();
                DataRow dr = ds.Tables[0].Rows[0];
                if (ds.Tables[0].Rows.Count != 0)
                {
                    txtName.Text = dr["DeptName"].ToString();
                    txtAbbreviation.Text = dr["Abbreviation"].ToString();
                    int InchargeId =Convert.ToInt32( dr["DeptInchargeId"]);
                    if (InchargeId > 0)
                    {
                        for (int i = 0; i < ddlIncharge.Items.Count; i++)
                        {
                            if (ddlIncharge.Items[i].Value == InchargeId.ToString())
                            {
                                j = i;
                            }
                            ddlIncharge.Items[i].Selected = false;
                        }
                        ddlIncharge.Items[j].Selected = true;
                    }
                    else
                    {
                        ddlIncharge.SelectedIndex = 0;
                        lblMsg.Text = "Assign Incharge for this Dept";
                    }
                }
                else
                {
                    lblMsg.Text = "No data found for this DeptId..";

                }
            }
            else
            {
                ClearData();
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void btnShowAll_Click(object sender, EventArgs e)
    {
        try
        {
            ClearData();
            if(ddlDeptId.Items.Count !=0)
            ddlDeptId.SelectedIndex = 0;
            lblMsg.Text = "";
            DataSet ds = objDept.GetAllDeptMasterData();
            ViewState["Data"] = ds;
            if (ds.Tables[0].Rows.Count != 0)
            {
                grdAllDepts.DataSource = ds.Tables[0];
                grdAllDepts.DataBind();
                grdAllDepts.Visible = true;
                btnCloseGrid.Visible = true;
            }
            else
            {
                lblMsg.Text = "No Records Found..";
            }
            //pnlAllData.Visible = true;
        }
        catch (Exception ex)
        {
            //pnlAllData.Visible = false;
            lblMsg.Text = "Error:Contact System Admin" + ex.Message;
        }
    }
    void ClearData()
    {
        txtName.Text = "";
        txtAbbreviation.Text = "";
        //txtLocation.Text = "";
        //txtDesc.Text = "";
        //lblMsg.Text = "";
    }
    void BindDeptIds()
    {
        try
        {
            //lblMsg.Text = "";
            DataSet ds = objDept.GetAllDeptIds();
            if (ds.Tables[0].Rows.Count != 0)
            {
                ddlDeptId.DataSource = ds.Tables[0];
                ddlDeptId.DataValueField = "DepartmentId";
                ddlDeptId.DataBind();
                ddlDeptId.Items.Insert(0, "--Select Department--");
            }
            else
            {
                lblMsg.Text = "No Records Found..";
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    void BindIncharges()
    {
        try
        {
            lblMsg.Text = "";
            DataSet ds = objDept.GetDeptIncharges();
            if (ds.Tables[0].Rows.Count != 0)
            {
                ddlIncharge.DataSource = ds.Tables[0];
                ddlIncharge.DataValueField = "EmpId";
                ddlIncharge.DataTextField = "Emp_FirstName";
                ddlIncharge.DataBind();
                ddlIncharge.Items.Insert(0, "--Select One--");
            }
            else
            {
                lblMsg.Text = "No Records Found..";
                ddlIncharge.Items.Insert(0, "--Select Incharge--");
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {

            if (RadioButtonList1.SelectedIndex == 0 && btnSubmit.Text == "Submit new record")
            {
                lblMsg.Text = "";
                
                txtName.Focus();
                objDept.DeptName = txtName.Text;
                objDept.Abbreviation = txtAbbreviation.Text;
                //objDept.DeptIncharge =Convert.ToInt32(ddlIncharge.SelectedItem.Value);
                //objDept.DeptDesc = txtDesc.Text;
                objDept.InsertDeptMaster();
                lblMsg.Text = "Your data inserted successfully..";
                
                BindDeptIds();                
                
            }

            else if (RadioButtonList1.SelectedIndex == 1 && btnSubmit.Text == "Modify record")
            {
                lblMsg.Text = "";
               
                objDept.DeptId = Convert.ToInt32(ddlDeptId.SelectedItem.Value);
                objDept.DeptName = txtName.Text;
                objDept.Abbreviation = txtAbbreviation.Text;
                objDept.DeptIncharge = Convert.ToInt32(ddlIncharge.SelectedItem.Value);
                //objDept.DeptDesc = txtDesc.Text;
                objDept.UpdateDeptMaster();
                lblMsg.Text = "Your data Updated successfully..";
                
                ddlDeptId.SelectedIndex = 0;
            }
        }

        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void btncancel_Click(object sender, EventArgs e)
    {
        if (RadioButtonList1.SelectedIndex == 0)
        {
            ClearData();
            txtName.Focus();
            lblMsg.Text = "";
        }
        else
        {
            ClearData();
            ddlDeptId.SelectedIndex = 0;
            ddlIncharge.Items.Clear();
            lblMsg.Text = "";
        }
    }
    protected void btnCloseGrid_Click(object sender, EventArgs e)
    {
        try
        {
            lblMsg.Text = "";
            grdAllDepts.Visible = false;
            btnCloseGrid.Visible = false;
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void ddlIncharge_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void grdAllDepts_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            DataSet ds = (DataSet)ViewState["Data"];
            if (ds.Tables[0].Rows.Count != 0)
            {
                grdAllDepts.PageIndex = e.NewPageIndex;
                grdAllDepts.DataSource = ds.Tables[0];
                grdAllDepts.DataBind();
                grdAllDepts.Visible = true;
                btnCloseGrid.Visible = true;
            }
            else
            {
                lblMsg.Text = "No Records Found..";
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
}
