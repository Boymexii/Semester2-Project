﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Admin_frmEmpRosterMaster : System.Web.UI.Page
{
    int j;
    clsEmployee objRoster = new clsEmployee();
    protected void Page_Load(object sender, EventArgs e)
    {
        lblMsg.Text = "";
        btnCloseGrid.Visible = false;
        if (!IsPostBack)
        {
            BindInchargeEmp();
        }
    }
    void ClearData()
    {
        txtDate.Text = "";
        
    }
    void BindInchargeEmp()
    {
        try
        {
            DataSet ds = objRoster.GetDeptIncharges();
            if(ds.Tables[0].Rows.Count !=0)
            {
                ddlIncharge.DataSource = ds.Tables[0];
                ddlIncharge.DataValueField = "EmpId";
                ddlIncharge.DataTextField = "Emp_FirstName";
                ddlIncharge.DataBind();
                ddlIncharge.Items.Insert(0, "--Select Employee--");
            }
           else
                {
                    lblMsg.Text = "No data available..";
                }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    void BindRosterIds()
    {
        try
        {
            DataSet ds = objRoster.GetAllRosterIds();
            if (ds.Tables[0].Rows.Count != 0)
            {
                ddlRosterId.DataSource = ds.Tables[0];
                ddlRosterId.DataValueField = "RosterId";
                //ddlRosterId.DataTextField = "Shift";
                ddlRosterId.DataBind();
                ddlRosterId.Items.Insert(0, "--Select Roster--");
            }
            else
            {
                lblMsg.Text = "No data available..";
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {

            if (RadioButtonList1.SelectedIndex == 0)
            {
                
                lblMsg.Text = "";
                txtEndTime.Text = "";
                txtStartTime.Text = "";
                txtStartTime.Enabled = false;
                txtEndTime.Enabled = false;
                ClearData();
                ddlAm.Enabled = true;
                ddlHH.Enabled = true;
                ddlMM.Enabled = true;
                ddlAM1.Enabled = true;
                ddlHH1.Enabled = true;
                ddlMM1.Enabled = true;
                btnSubmit.Text = "Submit new record";
                if (ddlRosterId.Items.Count != 0)
                    ddlRosterId.SelectedIndex = 0;
                ddlRosterId.Enabled = false;
            }
            else if (RadioButtonList1.SelectedIndex == 1)
            {
                lblMsg.Text = "";
                txtEndTime.Text = "";
                txtStartTime.Text = "";
                ddlHH.SelectedIndex = 0;
                ddlMM.SelectedIndex = 0;
                ddlHH1.SelectedIndex = 0;
                ddlMM1.SelectedIndex = 0;
                txtStartTime.Enabled = true;
                txtEndTime.Enabled = true;
                ddlAm.Enabled = false;
                ddlHH.Enabled = false;
                ddlMM.Enabled = false;
                ddlAM1.Enabled = false;
                ddlHH1.Enabled = false;
                ddlMM1.Enabled = false;
                grdAllRosters.Visible = false;
               btnCloseGrid.Visible = false;
                ClearData();
                btnSubmit.Text = "Modify record";
                BindRosterIds();
                ddlRosterId.Enabled = true;
            }
            btnSubmit.Enabled = true;
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void ddlRosterId_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlRosterId.SelectedIndex != 0)
            {
                lblMsg.Text = "";
                txtStartTime.Text = "";
                txtEndTime.Text = "";
                ddlAm.Enabled = false;
                ddlHH.Enabled = false;
                ddlMM.Enabled = false;
                ddlAM1.Enabled = false;
                ddlHH1.Enabled = false;
                ddlMM1.Enabled = false;
                objRoster.RosterId = Convert.ToInt32(ddlRosterId.SelectedItem.Value);
                DataSet ds = objRoster.GetEmpRosterMasterDataByRosterId();
                DataRow dr = ds.Tables[0].Rows[0];
                if (ds.Tables[0].Rows.Count != 0)
                {
                    txtDate.Text = dr["RosterDate"].ToString();
                    txtStartTime.Text = dr["RosterStartTime"].ToString();
                    txtEndTime.Text = dr["RosterEndTime"].ToString();

                    int InchargeId = Convert.ToInt32(dr["InchargeEmpId"]);
                    if (InchargeId > 0)
                    {
                        for (int i = 0; i < ddlIncharge.Items.Count; i++)
                        {
                            if (ddlIncharge.Items[i].Value == InchargeId.ToString())
                            {
                                j = i;
                            }
                            ddlIncharge.Items[i].Selected = false;
                        }
                        ddlIncharge.Items[j].Selected = true;
                    }
                }
                else
                {
                    lblMsg.Text = "No data found ";
                }
            }
            else
            {
                ClearData();
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void btnShowAll_Click(object sender, EventArgs e)
    {
        try
        {
            ClearData();
            if(ddlRosterId.Items.Count !=0)
            ddlRosterId.SelectedIndex = 0;
            lblMsg.Text = "";
            DataSet ds = objRoster.GetAllEmpRosterMasterData();
            ViewState["Data"] = ds;
            if (ds.Tables[0].Rows.Count != 0)
            {
                grdAllRosters.DataSource = ds.Tables[0];
                grdAllRosters.DataBind();
                grdAllRosters.Visible = true;
                btnCloseGrid.Visible = true;
            }
            else
            {
                grdAllRosters.EmptyDataText = "No Records Found..";
                grdAllRosters.DataBind();
            }
        }
        catch (Exception ex)
        {
            //pnlAllData.Visible = false;
            lblMsg.Text = "Error:Contact System Admin" + ex.Message;
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            if (RadioButtonList1.SelectedIndex == 0 && btnSubmit.Text == "Submit new record")
            {
                lblMsg.Text = "";
                objRoster.RosterDate = Convert.ToDateTime(txtDate.Text);
                string FromTime = ddlHH.SelectedItem.Value + ":" + ddlMM.SelectedItem.Value + " " + ddlAm.SelectedItem.Value;
                objRoster.StartTime = FromTime;
                string ToTime = ddlHH1.SelectedItem.Value + ":" + ddlMM1.SelectedItem.Value + " " + ddlAM1.SelectedItem.Value;
                objRoster.EndTime = ToTime;
                objRoster.RosterIncharge = Convert.ToInt32(ddlIncharge.SelectedItem.Value);
                lblMsg.Text = objRoster.InsertEmpRosterMaster();
                BindRosterIds();
                ddlIncharge.SelectedIndex = 0;
                ClearData();
            }
            else if (RadioButtonList1.SelectedIndex == 1 && btnSubmit.Text == "Modify record")
            {
                lblMsg.Text = "";
                objRoster.RosterId = Convert.ToInt32(ddlRosterId.SelectedItem.Value);
                objRoster.RosterDate = Convert.ToDateTime(txtDate.Text);
                objRoster.StartTime = txtStartTime.Text;
                objRoster.EndTime = txtEndTime.Text;
                objRoster.RosterIncharge = Convert.ToInt32(ddlIncharge.SelectedItem.Value);
                lblMsg.Text = objRoster.UpdateEmpRosterMaster();
                ClearData();
                ddlRosterId.SelectedIndex = 0;
                ddlIncharge.SelectedIndex = 0;
                txtStartTime.Text = "";
                txtEndTime.Text = "";
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        if (RadioButtonList1.SelectedIndex == 0)
        {
            ClearData();
            txtStartTime.Text = "";
            txtEndTime.Text = "";
            ddlIncharge.SelectedIndex = 0;
            lblMsg.Text = "";
        }
        else
        {
            ClearData();
            ddlRosterId.SelectedIndex = 0;
            txtStartTime.Text = "";
            txtEndTime.Text = "";
            ddlIncharge.SelectedIndex = 0;
            lblMsg.Text = "";
        }
    }
    protected void btnCloseGrid_Click(object sender, EventArgs e)
    {
        try
        {
            lblMsg.Text = "";
            grdAllRosters.Visible = false;
            btnCloseGrid.Visible = false;
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void grdAllRosters_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            DataSet ds = (DataSet)ViewState["Data"];
            if (ds.Tables[0].Rows.Count > 0)
            {
                grdAllRosters.PageIndex = e.NewPageIndex;
                grdAllRosters.DataSource = ds.Tables[0];
                grdAllRosters.DataBind();
                grdAllRosters.Visible = true;
                btnCloseGrid.Visible = true;
            }
            else
            {
                lblMsg.Text = "No Records Found..";
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
}
