﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Admin_frmSearchEmployeesByDate : System.Web.UI.Page
{
    clsEmployee objEmp = new clsEmployee();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        { 
         
        }
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        try
        {
            lblMsg.Text = "";
            gvEmp.Visible = false;
            objEmp.StartDate =Convert.ToDateTime(txtStartDate.Text);
            objEmp.EndDate = Convert.ToDateTime(txtEndDate.Text);

            DataSet ds = objEmp.GetEmpByDate();
            if (ds.Tables.Count != 0)
            {
                if (ds.Tables[0].Rows.Count >0)
                {
                    Cache["Data"] = ds;
                    gvEmp.DataSource = ds.Tables[0];
                    gvEmp.DataBind();
                    gvEmp.Visible = true;
                }
                else
                {
                    lblMsg.Text = "No Employees  are availbale between these dates..";
                  
                }
            }
            else
            {
               lblMsg.Text = "EndDate must be greater than or equal to StartDate..";
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;           
        }
    }
    protected void gvEmp_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            DataSet ds = (DataSet)Cache["Data"];
            if (ds.Tables[0].Rows.Count > 0)
            {
                gvEmp.PageIndex = e.NewPageIndex;
                gvEmp.DataSource = ds.Tables[0];
                gvEmp.DataBind();
                gvEmp.Visible = true;
            }
            else
            {
                gvEmp.Visible = false;
                lblMsg.Text = "No Employees  are availbale between these dates..";
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void btnShow_Click(object sender, EventArgs e)
    {
        try
        {
            lblMsg.Text = "";
            txtStartDate.Text = "";
            txtEndDate.Text = "";
            gvEmp.Visible = false;
            DataSet ds = objEmp.GetAllEmp();
            Cache["Data"] = ds;
            if (ds.Tables[0].Rows.Count > 0)
            {
                gvEmp.DataSource = ds.Tables[0];
                gvEmp.DataBind();
                gvEmp.Visible = true;
            }
            else
            {
                lblMsg.Text = "No Employees available..";
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
}
