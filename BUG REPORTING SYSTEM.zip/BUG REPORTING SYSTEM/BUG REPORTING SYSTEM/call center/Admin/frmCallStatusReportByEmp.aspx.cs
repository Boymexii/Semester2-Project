﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Admin_frmCallStatusReportByEmp : System.Web.UI.Page
{
    clsCustomer objCust = new clsCustomer();
    clsEmployee objShifts = new clsEmployee();
    protected void Page_Load(object sender, EventArgs e)
    {
        lblMsg.Text = "";
        if (!IsPostBack)
        {
            BindEmp();
        }
    }
    void BindEmp()
    {
        try
        {
            DataSet ds = objShifts.GetCallExecutes();
            if (ds.Tables[0].Rows.Count > 0)
            {
                ddlEmp.DataSource = ds.Tables[0];
                ddlEmp.DataValueField = "EmpId";
                ddlEmp.DataTextField = "Emp_FirstName";
                ddlEmp.DataBind();
                ddlEmp.Items.Insert(0, "--Select Emp--");
            }
            else
            {
                lblMsg.Text = "No Records Found.";
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void btnStatus_Click(object sender, EventArgs e)
    {
        try
        {
            lblMsg.Text = "";
            gvStatus.Visible = false;
            objCust.EmpId = Convert.ToInt32(ddlEmp.SelectedItem.Value);
            DataSet ds = objCust.GetCallStatusByEmp();
            ViewState["Data"] = ds;
            if (ds.Tables[0].Rows.Count > 0)
            {
                gvStatus.DataSource = ds.Tables[0];
                gvStatus.DataBind();
                gvStatus.Visible = true;
            }
            else
            {
                lblMsg.Text = "No Data Available..";
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void gvStatus_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            lblMsg.Text = "";
            gvStatus.Visible = false;
            DataSet ds = (DataSet)ViewState["Data"];
            if (ds.Tables[0].Rows.Count > 0)
            {
                gvStatus.PageIndex = e.NewPageIndex;
                gvStatus.DataSource = ds.Tables[0];
                gvStatus.DataBind();
                gvStatus.Visible = true;
            }
            else
            {
                lblMsg.Text = "No Data Available..";
            }

        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
}
