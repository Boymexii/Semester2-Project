﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Admin_frmServicesMaster : System.Web.UI.Page
{
    int j;
    clsCustomer objService = new clsCustomer();
    protected void Page_Load(object sender, EventArgs e)
    {
        lblMsg.Text = "";
        btnCloseGrid.Visible = false;
        if (!IsPostBack)
        { 
        
        }
    }
    void ClearData()
    {
        txtName.Text = "";
        txtAbbreviation.Text = "";
        //txtLocation.Text = "";
        txtDesc.Text = "";
        //lblMsg.Text = "";
    }
    void BindServicesIds()
    {
        try
        {
            //lblMsg.Text = "";
            DataSet ds = objService.GetAllServicesIds();
            if (ds.Tables[0].Rows.Count != 0)
            {
                ddlServiceId.DataSource = ds.Tables[0];
                ddlServiceId.DataValueField = "ServiceId";
                ddlServiceId.DataTextField = "ServiceName";
                ddlServiceId.DataBind();
                ddlServiceId.Items.Insert(0, "--Select One--");
            }
            else
            {
                lblMsg.Text = "No Records Found..";
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    void BindIncharges()
    {
        try
        {
            lblMsg.Text = "";
            DataSet ds = objService.GetServicesIncharges();
            if (ds.Tables[0].Rows.Count != 0)
            {
                ddlIncharge.DataSource = ds.Tables[0];
                ddlIncharge.DataValueField = "EmpId";
                ddlIncharge.DataTextField = "Emp_FirstName";
                ddlIncharge.DataBind();
                ddlIncharge.Items.Insert(0, "--Select One--");
            }
            else
            {
                lblMsg.Text = "No Records Found..";
                ddlIncharge.Items.Insert(0, "--Select One--");
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }

    protected void ddlServiceId_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            lblMsg.Text = "";
            if (ddlServiceId.SelectedIndex != 0)
            {
                grdAllServices.Visible = false;
                btnCloseGrid.Enabled = false;
                objService.ServiceId = Convert.ToInt32(ddlServiceId.SelectedItem.Value);
                BindIncharges();
                DataSet ds = objService.GetServicesMasterDataByServiceId();
                DataRow dr = ds.Tables[0].Rows[0];
                if (ds.Tables[0].Rows.Count != 0)
                {
                    txtName.Text = dr["ServiceName"].ToString();
                    txtAbbreviation.Text = dr["Abbreviation"].ToString();
                    txtDesc.Text = dr["Description"].ToString();
                    int InchargeId = Convert.ToInt32(dr["InchargeEmpId"]);
                    if (InchargeId > 0)
                    {
                        for (int i = 0; i < ddlIncharge.Items.Count; i++)
                        {
                            if (ddlIncharge.Items[i].Value == InchargeId.ToString())
                            {
                                j = i;
                            }
                            ddlIncharge.Items[i].Selected = false;
                        }
                        ddlIncharge.Items[j].Selected = true;
                    }
                    else
                    {
                        ddlIncharge.SelectedIndex = 0;
                    }
                }
                else
                {
                    lblMsg.Text = "No data found for this DeptId..";
                }
            }
            else
            {
                ClearData();
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            lblMsg.Text = "";
            if (RadioButtonList1.SelectedIndex == 0)
            {
                //grdAllDepts.Visible = false;
                //btnCloseGrid.Enabled = false;
                ClearData();
                ddlIncharge.Items.Clear();
                txtName.Focus();
                btnSubmit.Text = "Submit new record";
                btnSubmit.Enabled = true;
                 BindIncharges();
                if (ddlServiceId.Items.Count != 0)
                    ddlServiceId.SelectedIndex = 0;
                if (ddlIncharge.Items.Count != 0)
                    ddlIncharge.SelectedIndex = 0;
                ddlServiceId.Enabled = false;
                txtName.ReadOnly = false;
            }
            else if (RadioButtonList1.SelectedIndex == 1)
            {
                ddlIncharge.Items.Clear();
                grdAllServices.Visible = false;
                btnCloseGrid.Visible = false;
                ClearData();
                BindServicesIds();
                // BindIncharges();
                btnSubmit.Text = "Modify record";
                btnSubmit.Enabled = true;
                //txtName.ReadOnly = true;
                ddlServiceId.Enabled = true;
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void btnShowAll_Click(object sender, EventArgs e)
    {
        try
        {
            ClearData();
            if (ddlServiceId.Items.Count != 0)
                ddlServiceId.SelectedIndex = 0;
            lblMsg.Text = "";
            DataSet ds = objService.GetAllServicesMasterData();
            ViewState["Data"] = ds;
            if (ds.Tables[0].Rows.Count != 0)
            {
                grdAllServices.DataSource = ds.Tables[0];
                grdAllServices.DataBind();
                grdAllServices.Visible = true;
                btnCloseGrid.Visible = true;
            }
            else
            {
                grdAllServices.EmptyDataText = "No Records Found..";
                grdAllServices.DataBind();
            }
            //pnlAllData.Visible = true;
        }
        catch (Exception ex)
        {
            //pnlAllData.Visible = false;
            lblMsg.Text = "Error:Contact System Admin" + ex.Message;
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            if (RadioButtonList1.SelectedIndex == 0 && btnSubmit.Text == "Submit new record")
            {
                lblMsg.Text = "";

                txtName.Focus();
                objService.ServName = txtName.Text;
                objService.ServAbbrv = txtAbbreviation.Text;
                objService.ServIncharge = Convert.ToInt32(ddlIncharge.SelectedItem.Value);
                objService.ServDesc = txtDesc.Text;
                lblMsg.Text = objService.InsertServicesMaster(); 

                BindServicesIds();

            }

            else if (RadioButtonList1.SelectedIndex == 1 && btnSubmit.Text == "Modify record")
            {
                lblMsg.Text = "";

                objService.ServiceId = Convert.ToInt32(ddlServiceId.SelectedItem.Value);
                objService.ServName = txtName.Text;
                objService.ServAbbrv = txtAbbreviation.Text;
                objService.ServIncharge = Convert.ToInt32(ddlIncharge.SelectedItem.Value);
                objService.ServDesc = txtDesc.Text;
                
                lblMsg.Text = objService.UpdateServicesMaster();

                ddlServiceId.SelectedIndex = 0;
            }
        }

        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        if (RadioButtonList1.SelectedIndex == 0)
        {
            ClearData();
            txtName.Focus();
            lblMsg.Text = "";
            ddlIncharge.Items.Clear();
        }
        else
        {
            ClearData();
            ddlServiceId.SelectedIndex = 0;
            ddlIncharge.Items.Clear();
            lblMsg.Text = "";
        }
    }
    protected void btnCloseGrid_Click(object sender, EventArgs e)
    {
        try
        {
            lblMsg.Text = "";
            grdAllServices.Visible = false;
            btnCloseGrid.Visible = false;
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void ddlIncharge_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void grdAllServices_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            DataSet ds = (DataSet)ViewState["Data"];
            if (ds.Tables[0].Rows.Count != 0)
            {
                grdAllServices.DataSource = ds.Tables[0];
                grdAllServices.DataBind();
                grdAllServices.Visible = true;
                btnCloseGrid.Visible = true;
            }
            else
            {
                lblMsg.Text = "No Data Found..";
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }

}
