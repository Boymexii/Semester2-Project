﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Admin_frmEmpShiftsMaster : System.Web.UI.Page
{
    clsEmployee objShifts = new clsEmployee();
    protected void Page_Load(object sender, EventArgs e)
    {
        lblMsg.Text = "";
        btnCloseGrid.Visible = false;
        if (!IsPostBack)
        {
            BindEmp();
            BindRosters();
            BindCustomerIds();
            ddlService.Items.Insert(0, "--Select Service--");
            ddlService.Enabled = false;
        }
    }
    void ClearData()
    {
        try
        {
            if (ddlemp.Items.Count != 0)
                ddlemp.SelectedIndex = 0;
            if (ddlCustomer.Items.Count != 0)
                ddlCustomer.SelectedIndex = 0;
            if (ddlRoster.Items.Count != 0)
                ddlRoster.SelectedIndex = 0;
            if (ddlService.Items.Count != 0)
                ddlService.SelectedIndex = 0;
            
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    
    }
    void BindEmp()
    {
        try
        {
            DataSet ds = objShifts.GetCallExecutes();
            if (ds.Tables[0].Rows.Count > 0)
            {
                ddlemp.DataSource = ds.Tables[0];
                ddlemp.DataValueField = "EmpId";
                ddlemp.DataTextField = "Emp_FirstName";
                ddlemp.DataBind();
                ddlemp.Items.Insert(0, "--Select Emp--");
            }
            else
            {
                lblMsg.Text = "No Records Found.";
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    void BindRosters()
    {
        try
        {
            DataSet ds = objShifts.GetAllRosterIds();
            if (ds.Tables[0].Rows.Count > 0)
            {
                ddlRoster.DataSource = ds.Tables[0];
                ddlRoster.DataValueField = "RosterId";
                ddlRoster.DataTextField = "Shift";
                ddlRoster.DataBind();
                ddlRoster.Items.Insert(0, "--Select Roster--");
            }
            else
            {
                lblMsg.Text = "No Records Found.";
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    void BindCustomerIds()
    {
        try
        {
            DataSet ds = objShifts.GetAllCustomers();
            if (ds.Tables[0].Rows.Count > 0)
            {
                ddlCustomer.DataSource = ds.Tables[0];
                ddlCustomer.DataValueField = "CustomerId";
                ddlCustomer.DataTextField = "Cust_Name";
                ddlCustomer.DataBind();
                ddlCustomer.Items.Insert(0, "--Select Customer--");
            }
            else
            {
                lblMsg.Text = "No Records Found.";
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    //void BindServicesIds()
    //{
    //    try
    //    {
    //        DataSet ds = objShifts.GetAllServicesIds();
    //        if (ds.Tables[0].Rows.Count > 0)
    //        {
    //            ddlService.DataSource = ds.Tables[0];
    //            ddlService.DataValueField = "ServiceId";
    //            ddlService.DataTextField = "ServiceName";
    //            ddlService.DataBind();
    //            ddlService.Items.Insert(0, "--Select One--");
    //        }
    //        else
    //        {
    //            lblMsg.Text = "No Records Found.";
    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //        lblMsg.Text = ex.Message;
    //    }
    //}

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            lblMsg.Text = "";
            objShifts.EmpId = Convert.ToInt32(ddlemp.SelectedItem.Value);
            objShifts.CustId = Convert.ToInt32(ddlCustomer.SelectedItem.Value);
            objShifts.ServiceId = Convert.ToInt32(ddlService.SelectedItem.Value);
            objShifts.RosterId = Convert.ToInt32(ddlRoster.SelectedItem.Value);

           // objShifts.LoginTime=Convert.ToDateTime(System.da)

            //objShifts.NoOfClients =Convert.ToInt32( txtClients.Text);
            lblMsg.Text = objShifts.InsertEmpShiftsMaster();
            ClearData();
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;            
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        ClearData();
    }
    protected void btnShowAll_Click(object sender, EventArgs e)
    {
        try
        {
            ClearData();
            lblMsg.Text = "";
            DataSet ds = objShifts.GetAllEmpShiftsMasterData();
            ViewState["Data"] = ds;
            if (ds.Tables[0].Rows.Count != 0)
            {
                grdAllShifts.DataSource = ds.Tables[0];
                grdAllShifts.DataBind();
                grdAllShifts.Visible = true;
                btnCloseGrid.Visible = true;
            }
            else
            {
                lblMsg.Text = "No Records Found..";
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void btnCloseGrid_Click(object sender, EventArgs e)
    {
        try
        {
            lblMsg.Text = "";
            grdAllShifts.Visible = false;
            btnCloseGrid.Visible = false;
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void grdAllShifts_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            lblMsg.Text = "";
            DataSet ds = (DataSet)ViewState["Data"];
            if (ds.Tables[0].Rows.Count != 0)
            {
                grdAllShifts.DataSource = ds.Tables[0];
                grdAllShifts.DataBind();
                grdAllShifts.Visible = true;
                btnCloseGrid.Visible = true;
            }
            else
            {
                lblMsg.Text = "No Records Found..";
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void ddlCustomer_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlCustomer.SelectedIndex != 0)
            {
                objShifts.CustId = Convert.ToInt32(ddlCustomer.SelectedItem.Value);
                DataSet ds = objShifts.GetServicesIdsByCustId();
                if (ds.Tables[0].Rows.Count > 0)
                {
                    ddlService.DataSource = ds.Tables[0];
                    ddlService.DataValueField = "ServiceId";
                    ddlService.DataTextField = "ServiceName";
                    ddlService.DataBind();
                    ddlService.Enabled = true;
                   ddlService.Items.Insert(0, "--Select Service--");
                }
                else
                {
                    lblMsg.Text = "No Records Found.";
                }
            }
            else
            {
                ddlService.SelectedIndex = 0;
                lblMsg.Text = "";
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
}
