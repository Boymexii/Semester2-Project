﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Admin_frmDesgMaster : System.Web.UI.Page
{
    int j,k,m;
    clsEmployee objDesg = new clsEmployee();
    protected void Page_Load(object sender, EventArgs e)
    {
        lblMsg.Text = "";
        btnCloseGrid.Visible = false;
        if (!IsPostBack)
        {
            //BindDesignationIds();
        }
    }
    protected void ddlDesgId_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlDesgId.SelectedIndex != 0)
            {
                lblMsg.Text = "";
                objDesg.DesgId = Convert.ToInt32(ddlDesgId.SelectedItem.Value);
                DataSet ds = objDesg.GetDesgMasterDataByDesgId();
                DataRow dr = ds.Tables[0].Rows[0];
                if (ds.Tables[0].Rows.Count != 0)
                {
                    txtName.Text = dr["Desg_Name"].ToString();
                    txtAbbreviation.Text = dr["Abbreviation"].ToString();
                    //txtDesc.Text = dr["Desg_Description"].ToString();
                    int InchargeId =Convert.ToInt32( dr["Desg_InchargeId"]);
                    int Superior = Convert.ToInt32(dr["SuperiorDesgId"]);
                    if (InchargeId > 0)
                    {
                        for (int i = 0; i < ddlIncharge.Items.Count; i++)
                        {
                            if (ddlIncharge.Items[i].Value == InchargeId.ToString())
                            {
                                k = i;
                            }
                            ddlIncharge.Items[i].Selected = false;
                        }
                        ddlIncharge.Items[k].Selected = true;
                    }
                    else
                    {
                        lblMsg.Text = "No Data available..";
                    }
                    if (Superior > 0)
                    {
                        for (int i = 0; i < ddlSupDesg.Items.Count; i++)
                        {
                            if (ddlSupDesg.Items[i].Value == Superior.ToString())
                            {
                                m = i;
                            }
                            ddlSupDesg.Items[i].Selected = false;
                        }
                        ddlSupDesg.Items[m].Selected = true;
                    }
                    else
                    {
                        lblMsg.Text = "No Data available..";
                    }
                }
                else
                {
                    lblMsg.Text = "No data found for this DomainId..";
                }
            }
            else
            {
                ClearData();
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
             if (RadioButtonList1.SelectedIndex == 0)
            {
                lblMsg.Text = "";
                ClearData();
                ddlSupDesg.Items.Clear();
                txtName.Focus();
                //BindIncharges();
                btnSubmit.Text = "Submit new record";
                btnSubmit.Enabled = true;
                ddlDesgId.Enabled = false;
                if (ddlDesgId.Items.Count != 0)
                    ddlDesgId.SelectedIndex = 0;
                if (ddlIncharge.Items.Count != 0)
                    ddlIncharge.SelectedIndex = 0;

                if (ddlSupDesg.Items.Count != 0)
                    ddlSupDesg.SelectedIndex = 0;
            }
            else if (RadioButtonList1.SelectedIndex == 1)
            {
                lblMsg.Text = "";
                grdAllDesignations.Visible = false;
                btnCloseGrid.Visible = false;
                ClearData();
                ddlSupDesg.Items.Clear();
                btnSubmit.Text = "Modify record";
                btnSubmit.Enabled = true;
                BindDesignationIds();
                BindSupDesignationIds();
                BindIncharges();
                //txtName.ReadOnly = true;
                ddlDesgId.Enabled = true;
                if (ddlDesgId.Items.Count != 0)
                    ddlDesgId.SelectedIndex = 0;
                if (ddlIncharge.Items.Count != 0)
                    ddlIncharge.SelectedIndex = 0;

                //if (ddlSupDesg.Items.Count != 0)
                //    ddlSupDesg.SelectedIndex = 0;
            }

        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void btnShowAll_Click(object sender, EventArgs e)
    {
        try
        {
            ClearData();
            if (ddlDesgId.Items.Count != 0)
                ddlDesgId.SelectedIndex = 0;
            if (ddlIncharge.Items.Count != 0)
                ddlIncharge.SelectedIndex = 0;

            if (ddlSupDesg.Items.Count != 0)
                ddlSupDesg.SelectedIndex = 0;
            lblMsg.Text = "";
            DataSet ds = objDesg.GetAllDesgMasterData();
            if (ds.Tables[0].Rows.Count != 0)
            {
                grdAllDesignations.DataSource = ds.Tables[0];
                grdAllDesignations.DataBind();
                grdAllDesignations.Visible = true;
                btnCloseGrid.Visible = true;
            }
            else
            {
                grdAllDesignations.EmptyDataText = "No Records Found..";
                grdAllDesignations.DataBind();
            }
            //pnlAllData.Visible = true;
        }
        catch (Exception ex)
        {
            //pnlAllData.Visible = false;
            lblMsg.Text = "Error:Contact System Admin" + ex.Message;
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {

            if (RadioButtonList1.SelectedIndex == 0 && btnSubmit.Text == "Submit new record")
            {
                lblMsg.Text = "";
                objDesg.DesgName = txtName.Text;
                objDesg.DesgAbbreviation = txtAbbreviation.Text;
                //objDesg.DesgIncharge = Convert.ToInt32(ddlIncharge.SelectedItem.Value);
                //objDesg.SuperiorDesgId = Convert.ToInt32(ddlSupDesg.SelectedItem.Value);

                lblMsg.Text = objDesg.InsertDesgMaster();
                BindDesignationIds();
                ClearData();
                txtName.Focus();
            }

            else if (RadioButtonList1.SelectedIndex == 1 && btnSubmit.Text == "Modify record")
            {
                lblMsg.Text = "";
                objDesg.DesgId = Convert.ToInt32(ddlDesgId.SelectedItem.Value);
                objDesg.DesgName = txtName.Text;
                objDesg.DesgAbbreviation = txtAbbreviation.Text;
                objDesg.DesgIncharge = Convert.ToInt32(ddlIncharge.SelectedItem.Value);
                objDesg.SuperiorDesgId = Convert.ToInt32(ddlSupDesg.SelectedItem.Value);

                lblMsg.Text = objDesg.UpdateDesgMaster();
                ClearData();
                ddlDesgId.SelectedIndex = 0;
            }
        }

        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }

    void ClearData()
    {
        txtName.Text = "";
        txtAbbreviation.Text = "";
        //ddlIncharge.SelectedIndex=0;
        //lblMsg.Text = "";

    }
    void BindSupDesignationIds()
    {
        try
        {
            //lblMsg.Text = "";
            DataSet ds = objDesg.GetAllDesgIds();
            if (ds.Tables[0].Rows.Count != 0)
            {
                ddlSupDesg.DataSource = ds.Tables[0];
                ddlSupDesg.DataValueField = "DesignationId";
                ddlSupDesg.DataTextField = "Desg_Name";
                ddlSupDesg.DataBind();
                ddlSupDesg.Items.Insert(0, "--Select Designation--");
            }
            else
            {
                lblMsg.Text = "No Records Found..";
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    void BindIncharges()
    {
        try
        {
            //lblMsg.Text = "";
            DataSet ds = objDesg.GetDesgIncharges();
            if (ds.Tables[0].Rows.Count != 0)
            {
                ddlIncharge.DataSource = ds.Tables[0];
                ddlIncharge.DataValueField = "EmpId";
                ddlIncharge.DataTextField = "Emp_FirstName";
                ddlIncharge.DataBind();
                ddlIncharge.Items.Insert(0, "--Select Incharge--");
            }
            else
            {
                lblMsg.Text = "No Records Found..";
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    void BindDesignationIds()
    {
        try
        {
            //lblMsg.Text = "";
            DataSet ds = objDesg.GetAllDesgIds();
            if (ds.Tables[0].Rows.Count != 0)
            {
                ddlDesgId.DataSource = ds.Tables[0];
                ddlDesgId.DataValueField = "DesignationId";
                //ddlSupDesg.DataTextField = "Desg_Name";
                ddlDesgId.DataBind();
                ddlDesgId.Items.Insert(0, "--Select Designation--");
            }
            else
            {
                lblMsg.Text = "No Records Found..";
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void btncancel_Click(object sender, EventArgs e)
    {
        if (RadioButtonList1.SelectedIndex == 0)
        {
            ClearData();
            txtName.Focus();
            lblMsg.Text = "";
            ddlIncharge.SelectedIndex = 0;
            ddlSupDesg.Items.Clear();
        }
        else
        {
            ClearData();
            ddlIncharge.SelectedIndex = 0;
            ddlSupDesg.Items.Clear();
            ddlDesgId.SelectedIndex = 0;
            lblMsg.Text = "";
        }

    }
    protected void btnCloseGrid_Click(object sender, EventArgs e)
    {
        try
        {
            lblMsg.Text = "";
            grdAllDesignations.Visible = false;
            btnCloseGrid. Visible = false;
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }

    protected void ddlIncharge_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlIncharge.SelectedIndex != 0)
            {
                objDesg.DesgIncharge = Convert.ToInt32(ddlIncharge.SelectedItem.Value);
                DataSet ds = objDesg.GetDesgByIncharge();
                DataRow dr=ds.Tables[0].Rows[0];
                if(ds.Tables[0].Rows.Count>0)
                {
                    ddlSupDesg.DataSource = ds.Tables[0];
                    ddlSupDesg.DataValueField = "DesignationId";
                    ddlSupDesg.DataTextField = "Desg_Name";
                    ddlSupDesg.DataBind();
                    //ddlSupDesg.Items.Insert(0, "--Select One--");

                    int DesgId = Convert.ToInt32(dr["DesignationId"].ToString());
                    if (DesgId > 0)
                    {
                        for (int i = 0; i < ddlSupDesg.Items.Count; i++)
                        {
                            if (ddlSupDesg.Items[i].Value == DesgId.ToString())
                            {
                                j = i;
                            }
                            ddlSupDesg.Items[i].Selected = false;
                        }
                        ddlSupDesg.Items[j].Selected = true;
                    }
                    else
                    {
                        lblMsg.Text = "No Records Found..";
                    }
                }
                else
                {
                    lblMsg.Text = "No Records Found..";
                }
                
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void ddlSupDesg_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void grdAllDesignations_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            DataSet ds = (DataSet)ViewState["Data"];
            if (ds.Tables[0].Rows.Count != 0)
            {
                grdAllDesignations.DataSource = ds.Tables[0];
                grdAllDesignations.DataBind();
                grdAllDesignations.Visible = true;
                btnCloseGrid.Visible = true;
            }
            else
            {
                lblMsg.Text = "No Data Found..";
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
}
