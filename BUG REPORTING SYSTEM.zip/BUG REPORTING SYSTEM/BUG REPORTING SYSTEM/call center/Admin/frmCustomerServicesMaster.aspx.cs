﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Admin_frmCustomerServicesMaster : System.Web.UI.Page
{
    int j, k, m;
    clsCustomer objCustServ = new clsCustomer();
    protected void Page_Load(object sender, EventArgs e)
    {
        lblMsg.Text = "";
       // btnCloseGrid.Visible = false;
        if (!IsPostBack)
        {
            BindIncharges();
            BindCustomers();
            BindServices();
        }
    }
    void ClearData()
    {
        txtPhone1.Text = "";
        txtPhone2.Text = "";
        txtRegdDate.Text = "";
        txtExpDate.Text = "";
        if(ddlCustomer.Items.Count!=0)
        ddlCustomer.SelectedIndex = 0;
        if(ddlIncharge.Items.Count!=0)
        ddlIncharge.SelectedIndex = 0;
        if(ddlService.Items.Count!=0)
        ddlService.SelectedIndex = 0;
        //txtLocation.Text = "";
        //txtDesc.Text = "";
        //lblMsg.Text = "";
        
    }
    void BindCustomers()
    {
        try
        {
            //lblMsg.Text = "";
            DataSet ds = objCustServ.GetAllCustomers();
            if (ds.Tables[0].Rows.Count != 0)
            {
                ddlCustomer.DataSource = ds.Tables[0];
                ddlCustomer.DataValueField = "CustomerId";
                ddlCustomer.DataTextField = "Cust_Name";
                ddlCustomer.DataBind();
                ddlCustomer.Items.Insert(0, "--Select Customer--");
            }
            else
            {
                lblMsg.Text = "No Records Found..";
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    void BindCustServUnqNos()
    {
        try
        {
            //lblMsg.Text = "";
            DataSet ds = objCustServ.GetAllCustServUnqNos();
            if (ds.Tables[0].Rows.Count != 0)
            {
                ddlUnqNo.DataSource = ds.Tables[0];
                ddlUnqNo.DataValueField = "Cust_ServiceUniqueNo";
                //ddlCustomer.DataTextField = "Cust_Name";
                ddlUnqNo.DataBind();
                ddlUnqNo.Items.Insert(0, "--Select CustServ UnqNo--");
            }
            else
            {
                lblMsg.Text = "No Records Found..";
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    void BindServices()
    {
        try
        {
            //lblMsg.Text = "";
            DataSet ds = objCustServ.GetAllServicesIds();
            if (ds.Tables[0].Rows.Count != 0)
            {
                ddlService.DataSource = ds.Tables[0];
                ddlService.DataValueField = "ServiceId";
                ddlService.DataTextField = "ServiceName";
                ddlService.DataBind();
                ddlService.Items.Insert(0, "--Select Service--");
            }
            else
            {
                lblMsg.Text = "No Records Found..";
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    void BindIncharges()
    {
        try
        {
            lblMsg.Text = "";
            DataSet ds = objCustServ.GetServicesIncharges();
            if (ds.Tables[0].Rows.Count != 0)
            {
                ddlIncharge.DataSource = ds.Tables[0];
                ddlIncharge.DataValueField = "EmpId";
                ddlIncharge.DataTextField = "Emp_FirstName";
                ddlIncharge.DataBind();
                ddlIncharge.Items.Insert(0, "--Select Incharge--");
            }
            else
            {
                lblMsg.Text = "No Records Found..";
                ddlIncharge.Items.Insert(0, "--Select Incharge--");
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    //protected void grdAllCustServices_PageIndexChanging(object sender, GridViewPageEventArgs e)
    //{
    //    try
    //    {
    //        DataSet ds = (DataSet)ViewState["Data"];
    //        if (ds.Tables[0].Rows.Count != 0)
    //        {
    //            grdAllCustServices.PageIndex = e.NewPageIndex;
    //            grdAllCustServices.DataSource = ds.Tables[0];
    //            grdAllCustServices.DataBind();
    //            grdAllCustServices.Visible = true;
    //            btnCloseGrid.Visible = true;
    //        }
    //        else
    //        {
    //            lblMsg.Text = "No Data Found..";
    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //        lblMsg.Text = ex.Message;
    //    }
    //}
    protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            lblMsg.Text = "";
            if (RadioButtonList1.SelectedIndex == 0)
            {
                ddlService.Enabled = true;
                ddlCustomer.Enabled = true;
                txtRegdDate.Enabled = true;
                ClearData();
                btnSubmit.Text = "Submit new record";
                btnSubmit.Enabled = true;
                 //BindIncharges();
                 //BindCustomers();
                 //BindServices();
                if (ddlUnqNo.Items.Count != 0)
                    ddlUnqNo.SelectedIndex = 0;
                ddlUnqNo.Enabled = false;
            }
            else if (RadioButtonList1.SelectedIndex == 1)
            {
                ddlIncharge.Items.Clear();
                ddlService.Items.Clear();
                ddlCustomer.Items.Clear();
                //grdAllCustServices.Visible = false;
                //btnCloseGrid.Visible = false;
                ddlService.Enabled = false;
                ddlCustomer.Enabled = false;
                txtRegdDate.Enabled = false;
                ClearData();
                BindServices();
                BindCustomers();
                BindCustServUnqNos();
                // BindIncharges();
                btnSubmit.Text = "Modify record";
                btnSubmit.Enabled = true;
                
                ddlUnqNo.Enabled = true;
            }

        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void ddlUnqNo_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            lblMsg.Text = "";
            if (ddlUnqNo.SelectedIndex != 0)
            {
                //grdAllCustServices.Visible = false;
               // btnCloseGrid.Enabled = false;
                objCustServ.UniqueNo = Convert.ToInt32(ddlUnqNo.SelectedItem.Value);
                BindIncharges();
                DataSet ds = objCustServ.GetCustServMasterDataByUnqNO();
                DataRow dr = ds.Tables[0].Rows[0];
                if (ds.Tables[0].Rows.Count != 0)
                {
                    txtRegdDate.Text = dr["Cust_ServiceRegdDate"].ToString();
                    txtExpDate.Text = dr["Cust_ServiceExpDate"].ToString();
                    txtPhone1.Text = dr["PhoneNo1"].ToString();
                    txtPhone2.Text = dr["PhoneNo2"].ToString();
                    int InchargeId = Convert.ToInt32(dr["Cust_ServiceInchargeEmpId"]);
                    int CustId = Convert.ToInt32(dr["CustomerId"]);
                    int ServiceId = Convert.ToInt32(dr["ServiceId"]);

                    if (InchargeId > 0)
                    {
                        for (int i = 0; i < ddlIncharge.Items.Count; i++)
                        {
                            if (ddlIncharge.Items[i].Value == InchargeId.ToString())
                            {
                                j = i;
                            }
                            ddlIncharge.Items[i].Selected = false;
                        }
                        ddlIncharge.Items[j].Selected = true;
                    }
                    else
                    {
                        ddlIncharge.SelectedIndex = 0;
                    }

                    // customer id

                    if (CustId > 0)
                    {
                        for (int i = 0; i < ddlCustomer.Items.Count; i++)
                        {
                            if (ddlCustomer.Items[i].Value == CustId.ToString())
                            {
                                k = i;
                            }
                            ddlCustomer.Items[i].Selected = false;
                        }
                        ddlCustomer.Items[k].Selected = true;
                    }
                    else
                    {
                        ddlCustomer.SelectedIndex = 0;
                    }

                    // Service Id

                    if (ServiceId > 0)
                    {
                        for (int i = 0; i < ddlService.Items.Count; i++)
                        {
                            if (ddlService.Items[i].Value == ServiceId.ToString())
                            {
                                m = i;
                            }
                            ddlService.Items[i].Selected = false;
                        }
                        ddlService.Items[m].Selected = true;
                    }
                    else
                    {
                        ddlService.SelectedIndex = 0;
                    }
                }
                else
                {
                    lblMsg.Text = "No data found for this UniqueNo..";
                }
            }
            else
            {
                ClearData();
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    //protected void btnShowAll_Click(object sender, EventArgs e)
    //{
    //    try
    //    {
    //        ClearData();
    //        if (ddlUnqNo.Items.Count != 0)
    //            ddlUnqNo.SelectedIndex = 0;
    //        lblMsg.Text = "";
    //        DataSet ds = objCustServ.GetAllCustServMasterData();
    //        ViewState["Data"] = ds;
    //        if (ds.Tables[0].Rows.Count != 0)
    //        {
    //            grdAllCustServices.DataSource = ds.Tables[0];
    //            grdAllCustServices.DataBind();
    //            grdAllCustServices.Visible = true;
    //            btnCloseGrid.Visible = true;
    //        }
    //        else
    //        {
    //            grdAllCustServices.EmptyDataText = "No Records Found..";
    //            grdAllCustServices.DataBind();
    //        }
    //        //pnlAllData.Visible = true;
    //    }
    //    catch (Exception ex)
    //    {
    //        //pnlAllData.Visible = false;
    //        lblMsg.Text = "Error:Contact System Admin" + ex.Message;
    //    }
    //}
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            if (RadioButtonList1.SelectedIndex == 0 && btnSubmit.Text == "Submit new record")
            {
                lblMsg.Text = "";

                //txtName.Focus();
               objCustServ.CustId = Convert.ToInt32(ddlCustomer.SelectedItem.Value);
               objCustServ.ServiceId = Convert.ToInt32(ddlService.SelectedItem.Value);
               objCustServ.CustServIncharge = Convert.ToInt32(ddlIncharge.SelectedItem.Value);
               objCustServ.CustServRegdDate =Convert.ToDateTime( txtRegdDate.Text);
               objCustServ.CustServExpDate = Convert.ToDateTime(txtExpDate.Text);
               objCustServ.PhoneNo1 = txtPhone1.Text;
               objCustServ.PhoneNo2 = txtPhone2.Text;
               lblMsg.Text = objCustServ.InsertCustomerServicesMaster();

                BindCustServUnqNos();
            }

            else if (RadioButtonList1.SelectedIndex == 1 && btnSubmit.Text == "Modify record")
            {
                lblMsg.Text = "";
                objCustServ.UniqueNo = Convert.ToInt32(ddlUnqNo.SelectedItem.Value);
                objCustServ.CustId = Convert.ToInt32(ddlCustomer.SelectedItem.Value);
                objCustServ.ServiceId = Convert.ToInt32(ddlService.SelectedItem.Value);
                objCustServ.CustServIncharge = Convert.ToInt32(ddlIncharge.SelectedItem.Value);
                objCustServ.CustServRegdDate = Convert.ToDateTime(txtRegdDate.Text);
                objCustServ.CustServExpDate = Convert.ToDateTime(txtExpDate.Text);
                objCustServ.PhoneNo1 = txtPhone1.Text;
                objCustServ.PhoneNo2 = txtPhone2.Text;
                lblMsg.Text = objCustServ.UpdateCustomerServicesMaster();

                ddlUnqNo.SelectedIndex = 0;
            }
        }

        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        if (RadioButtonList1.SelectedIndex == 0)
        {
            ClearData();
           // txtName.Focus();
            lblMsg.Text = "";
        }
        else
        {
            ClearData();
            ddlUnqNo.SelectedIndex = 0;
            
            lblMsg.Text = "";
        }
    }
    //protected void btnCloseGrid_Click(object sender, EventArgs e)
    //{
    //    try
    //    {
    //        lblMsg.Text = "";
    //        grdAllCustServices.Visible = false;
    //        btnCloseGrid.Visible = false;
    //    }
    //    catch (Exception ex)
    //    {
    //        lblMsg.Text = ex.Message;
    //    }
    //}
}
