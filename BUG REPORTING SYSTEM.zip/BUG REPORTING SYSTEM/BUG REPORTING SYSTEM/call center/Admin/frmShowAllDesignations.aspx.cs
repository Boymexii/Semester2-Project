﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Admin_frmShowAllDesignations : System.Web.UI.Page
{
    clsEmployee objDesg = new clsEmployee();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        { 
         
        }
    }
    protected void btnShow_Click(object sender, EventArgs e)
    {
        try
        {
            lblMsg.Text = "";
            DataSet ds = objDesg.GetAllDesgMasterData();
            ViewState["Data"] = ds;
            if (ds.Tables[0].Rows.Count > 0)
            {
                gvDesg.DataSource = ds.Tables[0];
                gvDesg.DataBind();
            }
            else
            {
                lblMsg.Text = " No Data available..";
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void gvDesg_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            DataSet ds = (DataSet)ViewState["Data"];
            if (ds.Tables[0].Rows.Count > 0)
            {
                gvDesg.PageIndex = e.NewPageIndex;
                gvDesg.DataSource = ds.Tables[0];
                gvDesg.DataBind();
            }
            else
            {
                lblMsg.Text = " No Data available..";
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
}
