﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        lblMsg.Text = "";
        string url = Request.Url.ToString();
        string[] split = url.Split('/');
        for (int i = 0; i < split.Length; i++)
        {
            if (split[i] == "Admin")
            {
                lblHead.Text = "Admin Login";
            }
            else if (split[i] == "Emp")
            {
                lblHead.Text = "Employee Login";
            }
        }
        if (Session["UserName"] != null)
        {
            FormsAuthentication.SignOut();
        }

    }
    clsLogin objLogin = new clsLogin();

    protected void ImgBtnEmail_Click(object sender, EventArgs e)
    {
        if (txtusername.Text == "admin" && txtpassword.Text == "admin")
        {
            Response.Redirect("~/Admin/Default.aspx");

        }
        else
        {
            if (txtusername.Text == "employee" && txtpassword.Text == "employee")
            {
                Response.Redirect("~/EmpDefault.aspx");

            }
            else
            {
                string str1 = null;
                string[] UserName = null;
                try
                {
                    if (txtusername.Text.Contains("@"))
                    {
                        string str = txtusername.Text;
                        UserName = str.Split('@');
                        clsLogin.UserName = UserName[0].ToString();
                        str1 = UserName[0].ToString();
                    }
                    else
                    {
                        clsLogin.UserName = txtusername.Text.Trim();
                        str1 = txtusername.Text.Trim();
                    }
                    clsLogin.Password = txtpassword.Text.Trim();
                    int id;
                    DateTime LoginDateTime;
                    string Role = clsLogin.GetUserLogin(out id, out LoginDateTime);
                    if (Role == "NoUser")
                        lblMsg.Text = "User Name and password mismatch. Try again.";
                    else
                    {
                        Session["UserId"] = id;
                        Session["LoginDate"] = LoginDateTime;
                        if (Role.ToLower() == "admin")
                        {
                            Session["UserName"] = str1;
                            FormsAuthentication.RedirectFromLoginPage("Admin", false);
                        }
                        else if (Role.ToLower() == "emp")
                        {
                            Session["UserName"] = str1;
                            FormsAuthentication.RedirectFromLoginPage("Emp", false);
                        }
                    }
                }
                catch (Exception ex)
                {
                    lblMsg.Text = ex.Message;
                }
            }
        }
    }
}
