﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using CallCenterManagement.DAL;

/// <summary>
/// Summary description for clsHoliday
/// </summary>
public class clsHoliday:clsConnection
{
	public clsHoliday()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public int HolidayId { get; set; }
    public DateTime HolidayDate { get; set; }
    public string Reason { get; set; }
    public int ScruitinizedEmp { get; set; }

    public string InsertHolidayMaster()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[4];
            p[0]=new SqlParameter ("@HolidayDate",HolidayDate);
            p[1] = new SqlParameter("@Reason", Reason);
            p[2] = new SqlParameter("@ScruitinizedEmpId", ScruitinizedEmp);
            p[3] = new SqlParameter("@Message", SqlDbType.VarChar, 250);
            p[3].Direction = ParameterDirection.Output;
            SqlHelper.ExecuteNonQuery(clsConnection.Connection, CommandType.StoredProcedure, "sp_InsertHolidayMaster", p);
            return p[3].Value.ToString();

        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public string UpdateHolidayMaster()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[5];
            p[0] = new SqlParameter("@HolidayDate", HolidayDate);
            p[1] = new SqlParameter("@Reason", Reason);
            p[2] = new SqlParameter("@ScruitinizedEmpId", ScruitinizedEmp);
            p[3] = new SqlParameter("@Message", SqlDbType.VarChar, 250);
            p[3].Direction = ParameterDirection.Output;
            p[4]=new SqlParameter ("@HolidayId",HolidayId);
            SqlHelper.ExecuteNonQuery(clsConnection.Connection, CommandType.StoredProcedure, "sp_UpdateHolidayMaster", p);
            return p[3].Value.ToString();
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }

    public DataSet GetHolidayMasterDataByHolidayId()
    {
        try
        {
            string str = "select * from tbl_HolidayMaster where HolidayId=" + this.HolidayId;
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.Text, str);
     }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }

    public DataSet GetAllHolidayMasterData()
    {
        try
        {
            //string str = "select * from tbl_HolidayMaster ";
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.StoredProcedure,"sp_GetAllHolidayMasterData",null);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetAllHolidayIds()
    {
        try
        {
            string str = "select HolidayId from tbl_HolidayMaster";
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.Text, str);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetScruitinizedEmp()
    {
        try
        {
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.StoredProcedure, "sp_GetScruitinizedEmp",null);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
}
