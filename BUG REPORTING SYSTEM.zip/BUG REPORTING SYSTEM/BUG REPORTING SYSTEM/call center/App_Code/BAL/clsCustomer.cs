﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using CallCenterManagement.DAL;
/// <summary>
/// Summary description for clsCustomer
/// </summary>
public class clsCustomer:clsConnection
{
	public clsCustomer()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public int EmpId { get; set; }
    public int CustId { get; set; }
    public string PhoneNo { get; set; }
    public string PhoneNo1 { get; set; }
    public string PhoneNo2 { get; set; }
    public string Remarks { get; set; }
    public string CustName { get; set; }
    public string Address { get; set; }
    public string Email { get; set; }
    public DateTime RegdDate { get; set; }
    public DateTime ExpDate { get; set; }

    public int ServiceId { get; set; }
    public int ServIncharge { get; set; }
    public string ServName { get; set; }
    public string  ServAbbrv{ get; set; }
    public string ServDesc { get; set; }

    public DateTime LoginDate { get; set; }
    public int UniqueNo { get; set; }
    public DateTime CustServRegdDate { get; set; }
    public DateTime CustServExpDate { get; set; }
    public int CustServIncharge { get; set; }
    public string CustServPhoneNo { get; set; }


    public string InsertCustomerMaster()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[4];
            p[0] = new SqlParameter("@CustName", CustName);
            //p[1] = new SqlParameter("@CustRegdDate", RegdDate);
           // p[2] = new SqlParameter("@CustRegdExpDate", ExpDate);
            p[1] = new SqlParameter("@CustAddress", Address);
            p[2] = new SqlParameter("@CustEmail", Email);
            p[3] = new SqlParameter("@Message", SqlDbType.VarChar, 250);
            p[3].Direction = ParameterDirection.Output;
            SqlHelper.ExecuteNonQuery(clsConnection.Connection, CommandType.StoredProcedure, "sp_InsertCustomerMaster", p);
            return p[3].Value.ToString();
        }
        catch (Exception ex)
        { 
        
         throw new ArgumentException (ex.Message);
        }
    }
    public string UpdateCustomerMaster()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[5];
            p[0] = new SqlParameter("@CustName", CustName);
            //p[1] = new SqlParameter("@CustRegdDate", RegdDate);
           // p[2] = new SqlParameter("@CustRegdExpDate", ExpDate);
            p[1] = new SqlParameter("@CustAddress", Address);
            p[2] = new SqlParameter("@CustEmail", Email);
            p[3] = new SqlParameter("@Message", SqlDbType.VarChar, 250);
            p[3].Direction = ParameterDirection.Output;
            p[4] = new SqlParameter("@CustId", CustId);
            SqlHelper.ExecuteNonQuery(clsConnection.Connection, CommandType.StoredProcedure, "sp_UpdateCustomerMaster", p);
            return p[3].Value.ToString();
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetAllCustomers()
    {
        try 
        {
            string strCust = "select * from tbl_CustomerMaster";
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.Text, strCust);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetCustomerMasterDataByCustId()
    {
        try
        {
            string str = "select * from tbl_CustomerMaster where CustomerId=" + this.CustId;
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.Text, str);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        } 
    }

    public string InsertServicesMaster()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[5];
            p[0] = new SqlParameter("@ServiceName", ServName);
            p[1] = new SqlParameter("@Abbreviation", ServAbbrv);
            p[2] = new SqlParameter("@Desc", ServDesc);
            p[3] = new SqlParameter("@InchargeId", ServIncharge);
            p[4] = new SqlParameter("@Message", SqlDbType.VarChar, 250);
            p[4].Direction = ParameterDirection.Output;
            SqlHelper.ExecuteNonQuery(clsConnection.Connection, CommandType.StoredProcedure, "sp_InsertServicesMaster", p);
            return p[4].Value.ToString();
        }
        catch (Exception ex)
        {

            throw new ArgumentException(ex.Message);
        }
    }
    public string UpdateServicesMaster()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[6];
            p[0] = new SqlParameter("@ServiceName", ServName);
            p[1] = new SqlParameter("@Abbreviation", ServAbbrv);
            p[2] = new SqlParameter("@Desc", ServDesc);
            p[3] = new SqlParameter("@InchargeId", ServIncharge);
            p[4] = new SqlParameter("@Message", SqlDbType.VarChar, 250);
            p[4].Direction = ParameterDirection.Output;
            p[5] = new SqlParameter("@ServiceId", ServiceId);
            SqlHelper.ExecuteNonQuery(clsConnection.Connection, CommandType.StoredProcedure, "sp_UpdateServicesMaster", p);
            return p[4].Value.ToString();
        }
        catch (Exception ex)
        {

            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetAllServicesIds()
    {
        try
        {
            string strCust = "select ServiceId,ServiceName  from tbl_ServicesMaster";
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.Text, strCust);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetServicesIncharges()
    {
        try
        {
            
            //string str = "select EmpId,Emp_FirstName from tbl_Emp_Master";
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.StoredProcedure,"sp_GetServicesIncharges",null);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetServicesMasterDataByServiceId()
    {
        try
        {
            string str = "select * from tbl_ServicesMaster where ServiceId=" + this.ServiceId;
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.Text, str);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetAllServicesMasterData()
    {
        try
        {
            //string str = "select * from tbl_Dept_Master ";
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.StoredProcedure, "sp_GetAllServicesMasterData", null);
        }

        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }

    //Customer Services//
    public string InsertCustomerServicesMaster()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[8];
            p[0] = new SqlParameter("@CustId", CustId);
            p[1] = new SqlParameter("@ServiceId", ServiceId);
            p[2] = new SqlParameter("@CustServiceRegdDate", CustServRegdDate);
            p[3] = new SqlParameter("@CustServiceExpDate", CustServExpDate);
            p[4] = new SqlParameter("@InchargeId", CustServIncharge);
            p[5] = new SqlParameter("@Message", SqlDbType.VarChar, 250);
            p[5].Direction = ParameterDirection.Output;
            p[6] = new SqlParameter("@PhoneNo1", PhoneNo1);
            p[7] = new SqlParameter("@PhoneNo2", PhoneNo2);
            SqlHelper.ExecuteNonQuery(clsConnection.Connection,CommandType.StoredProcedure,"sp_InsertCustomerServicesMaster",p);
            return p[5].Value.ToString();
        }
        catch (Exception ex)
        {

            throw new ArgumentException(ex.Message);
        }
    }

    public string UpdateCustomerServicesMaster()
    {
        try
        {
             SqlParameter[] p = new SqlParameter[9];
            p[0] = new SqlParameter("@CustId", CustId);
            p[1] = new SqlParameter("@ServiceId", ServiceId);
            p[2] = new SqlParameter("@CustServiceRegdDate", CustServRegdDate);
            p[3] = new SqlParameter("@CustServiceExpDate", CustServExpDate);
            p[4] = new SqlParameter("@InchargeId", CustServIncharge);
            p[5] = new SqlParameter("@Message", SqlDbType.VarChar, 250);
            p[5].Direction = ParameterDirection.Output;
            p[6]=new SqlParameter ("@CustServiceUniqueNo",UniqueNo);
            p[7] = new SqlParameter("@PhoneNo1", PhoneNo1);
            p[8] = new SqlParameter("@PhoneNo2", PhoneNo2);
            SqlHelper.ExecuteNonQuery(clsConnection.Connection,CommandType.StoredProcedure,"sp_UpdateCustomerServicesMaster",p);
            return p[5].Value.ToString();
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetAllCustServUnqNos()
    {
        try
        {
            string str = "select Cust_ServiceUniqueNo from tbl_CustomerServicesMaster";
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.Text, str);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetAllCustServMasterData()
    {
        try
        {
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.StoredProcedure, "sp_GetAllCustServMasterData", null);

        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetCustServMasterDataByUnqNO()
    {
        try
        {
            string str = "select * from tbl_CustomerServicesMaster where Cust_ServiceUniqueNo=" + this.UniqueNo;
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.Text, str);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }

    public string InsertCustServPhoneNos()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[3];
            p[0] = new SqlParameter("@CustServiceUnqNo", UniqueNo);
            p[1] = new SqlParameter("@PhoneNo", CustServPhoneNo);
            p[2] = new SqlParameter("@Message", SqlDbType.VarChar, 250);
            p[2].Direction = ParameterDirection.Output;
            SqlHelper.ExecuteNonQuery(clsConnection.Connection,CommandType.StoredProcedure,"sp_InsertCustomerServicesPhoneNos",p);
            return p[2].Value.ToString();

        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetAllServicesPhoneNos()
    {
        try
        {
            string str = "select  Cust_ServiceUniqueNo,PhoneNo from tbl_CustomerServicesPhoneNumbers";
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.Text, str);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }

    // Request Customer Master//
    public string InsertRequestCustomerMaster()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[8];
            p[0] = new SqlParameter("@CustName", CustName);
            p[1] = new SqlParameter("@Remarks", Remarks);
            p[2] = new SqlParameter("@PhoneNo", PhoneNo);
            p[3] = new SqlParameter("@Address", Address);
            p[4] = new SqlParameter("@Email", Email);
            p[5] = new SqlParameter("@Message", SqlDbType.VarChar, 250);
            p[5].Direction = ParameterDirection.Output;
            p[6] = new SqlParameter("@EmpId", EmpId);
            p[7] = new SqlParameter("@LoginDate", LoginDate);
            SqlHelper.ExecuteNonQuery(clsConnection.Connection, CommandType.StoredProcedure, "sp_InsertRequestCustomerMaster", p);
            return p[5].Value.ToString();
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public string UpdateRequestCustomerMaster()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[7];
            p[0] = new SqlParameter("@CustName", CustName);
            p[1] = new SqlParameter("@Remarks", Remarks);
            p[2] = new SqlParameter("@PhoneNo", PhoneNo);
            p[3] = new SqlParameter("@Address", Address);
            p[4] = new SqlParameter("@Email", Email);
            p[5] = new SqlParameter("@Message", SqlDbType.VarChar, 250);
            p[5].Direction = ParameterDirection.Output;
            p[6] = new SqlParameter("@CustId", CustId);
            SqlHelper.ExecuteNonQuery(clsConnection.Connection, CommandType.StoredProcedure, "sp_UpdateRequestCustomerMaster", p);
            return p[5].Value.ToString();
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetAllRequestCustomers()
    {
        try
        {
            string strCust = "select * from tbl_RequestCustomerMaster";
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.Text, strCust);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetRequestCustomerMasterDataByCustId()
    {
        try
        {
            string str = "select * from tbl_RequestCustomerMaster where CustomerId=" + this.CustId;
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.Text, str);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public void GetLogoutTime()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[2];
            p[0] = new SqlParameter("@EmpId", EmpId);
            p[1] = new SqlParameter("@LoginDate", LoginDate);
           // DateTime dt = System.DateTime.Now;
             SqlHelper.ExecuteNonQuery(clsConnection.Connection, CommandType.StoredProcedure,"sp_GetLogoutTime",p);

        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetCallStatus()
    {
        try
        {
        return  SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.StoredProcedure,"sp_GetCallStatus",null);

        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetCallStatusByEmp()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[1];
            p[0] = new SqlParameter("@EmpId", EmpId);
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.StoredProcedure, "sp_GetCallStatusByEmp", p);

        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
}
