﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using CallCenterManagement.DAL;
/// <summary>
/// Summary description for clsDept
/// </summary>
public class clsDept:clsConnection
{
	public clsDept()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    
    public DataSet GetDeptID()
    {
        string strText = "select * from tbl_Dept_Master";
        DataSet ds = SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.Text, strText, null);
        return ds;
    }
    public DataSet GetDesignation()
    {
        string strText = "select * from tbl_DesignationMaster";
        DataSet ds = SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.Text, strText, null);
        return ds;
    }
    public DataSet GetQualifications()
    {
        string strText = "select * from tbl_Qualification_IdentifiedMaster";
        DataSet ds = SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.Text, strText, null);
        return ds;
    }
    public DataSet GetManagersID(int strDeptId)
    {
        string strText = "select * from tbl_Emp_Master where Emp_FirstDeptId=" + strDeptId;
        DataSet ds = SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.Text, strText, null);
        return ds;
    }
    public DataSet GetManagersByDeptId(int intDeptId)
    {
        SqlParameter[] p = new SqlParameter[1];
        p[0] = new SqlParameter("@DeptId",intDeptId);
        p[0].SqlDbType = SqlDbType.Int;
        DataSet ds = SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.StoredProcedure, "sp_GetManagersByDeptId", p);
        return ds;
    }
}
