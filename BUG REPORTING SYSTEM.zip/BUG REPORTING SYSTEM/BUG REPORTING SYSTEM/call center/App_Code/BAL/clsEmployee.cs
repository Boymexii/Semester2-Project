﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using CallCenterManagement.DAL;

/// <summary>
/// Summary description for clsEmployee
/// </summary>
public class clsEmployee:clsConnection
{
	public clsEmployee()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
    public int DeptId { get; set; }
    public string DeptName { get; set; }
    public string  Abbreviation { get; set; }
    public int DeptIncharge { get; set; }
   // public string  DeptDesc{ get; set; }

    public int DesgId { get; set; }
    public string DesgName{ get; set; }
    public string DesgAbbreviation { get; set; }
    public int DesgIncharge { get; set; }
    public int SuperiorDesgId { get; set; }
   // public string DesgDesc { get; set; }

    public int EmpId { get; set; }
    public int CustId { get; set; }
    public int ServiceId { get; set; }
    public int RosterId { get; set; }
    public int RosterIncharge { get; set; }
    public DateTime RosterDate { get; set; }
    public string StartTime { get; set; }
    public string EndTime { get; set; }
    public DateTime  LogTime { get; set; }
    public DateTime LogoffTime { get; set; }
    public int NoOfClients { get; set; }
    public string Status { get; set; }

    public string OldPwd { get; set; }
    public string NewPwd { get; set; }
    public string ConfirmPwd { get; set; }


    //Dept Data//
    public DataSet InsertDeptMaster()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[2];
            p[0] = new SqlParameter("@DeptName", DeptName);
            p[1] = new SqlParameter("@Abbreviation", Abbreviation);
            //p[2] = new SqlParameter("@DeptInchargeId", DeptIncharge);
           // p[3] = new SqlParameter("@DeptDescription",DeptDesc);

           return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.StoredProcedure, "sp_InsertDeptMaster", p);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet UpdateDeptMaster()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[4];
            p[0] = new SqlParameter("@DeptId", DeptId);
            p[1] = new SqlParameter("@DeptName", DeptName);
            p[2] = new SqlParameter("@Abbreviation", Abbreviation);
            p[3] = new SqlParameter("@DeptInchargeId", DeptIncharge);
           // p[4] = new SqlParameter("@DeptDesc", DeptDesc);
           return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.StoredProcedure, "sp_UpdateDeptMaster", p);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetAllDeptIds()
    {
        try
        {
            string str = "select DepartmentId from tbl_Dept_Master";
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.Text, str);
        }
         
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetDeptMasterDataByDeptId()
    {
        try
        {
           // string str = "select * from tbl_Dept_Master where DepartmentId=" + this.DeptId;
            SqlParameter[] p = new SqlParameter[1];
            p[0] = new SqlParameter("@DeptId", DeptId);
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.StoredProcedure, "sp_GetDeptMasterDataByDeptId",p);
        }
         
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetDeptIncharges()
    {
        try
        {
            //SqlParameter[] p = new SqlParameter[1];
            //p[0] = new SqlParameter("@DeptId", DeptId);
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.StoredProcedure,"sp_GetDeptIncharges",null);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetAllDeptMasterData()
    {
        try
        {
            //string str = "select * from tbl_Dept_Master ";
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.StoredProcedure,"sp_GetAllDeptMasterData",null);
        }
         
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }



    // Designation Master
    //
    //
    public string InsertDesgMaster()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[3];
            p[0] = new SqlParameter("@DesgName", DesgName);
            p[1] = new SqlParameter("@Abbreviation", DesgAbbreviation);
          
            p[2] = new SqlParameter("@Message", SqlDbType.VarChar, 250);
            p[2].Direction = ParameterDirection.Output;
            SqlHelper.ExecuteNonQuery(clsConnection.Connection, CommandType.StoredProcedure, "sp_InsertDesgMaster", p);
            return p[2].Value.ToString();
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public string UpdateDesgMaster()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[6];
            p[0] = new SqlParameter("@DesgId", DesgId);
            p[1] = new SqlParameter("@DesgName", DesgName);
            p[2] = new SqlParameter("@Abbreviation", DesgAbbreviation);
            p[3] = new SqlParameter("@DesgInchargeId", DesgIncharge);
            p[4] = new SqlParameter("@SuperiorDesgId", SuperiorDesgId);
            p[5] = new SqlParameter("@Message", SqlDbType.VarChar, 250);
            p[5].Direction = ParameterDirection.Output;
             SqlHelper.ExecuteNonQuery(clsConnection.Connection, CommandType.StoredProcedure, "sp_UpdateDesgMaster", p);
            return p[5].Value.ToString();
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetAllDesgIds()
    {
        try
        {
        string str = "select DesignationId,Desg_Name from tbl_DesignationMaster";
        return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.Text, str);
         }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetDesgIncharges()
    {
        try
        {
            string str = "select * from tbl_Emp_Master";
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.Text, str);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetDesgByIncharge()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[1];
            p[0] = new SqlParameter("@EmpId", DesgIncharge);
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.StoredProcedure, "sp_GetDesgByIncharge", p);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetDesgMasterDataByDesgId()
    {
        try
        {
        string str = "select * from tbl_DesignationMaster where DesignationId=" + this.DesgId;
        return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.Text, str);
         }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetAllDesgMasterData()
    {
        try
        {

            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.StoredProcedure, "sp_GetAllDesgMasterData",null);
         }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }

    //Roster Master

    public string InsertEmpRosterMaster()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[5];
            p[0] = new SqlParameter("@RosterDate", RosterDate);
            p[1] = new SqlParameter("@StartTime", StartTime);
            p[2] = new SqlParameter("@EndTime", EndTime);
            p[3] = new SqlParameter("@InchargeId", RosterIncharge);
            p[4] = new SqlParameter("@Message", SqlDbType.VarChar, 250);
            p[4].Direction = ParameterDirection.Output;
             SqlHelper.ExecuteNonQuery(clsConnection.Connection,CommandType.StoredProcedure,"sp_InsertEmpRosterMaster",p);
            return p[4].Value.ToString();
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public string UpdateEmpRosterMaster()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[6];
            p[0] = new SqlParameter("@RosterDate", RosterDate);
            p[1] = new SqlParameter("@StartTime", StartTime);
            p[2] = new SqlParameter("@EndTime", EndTime);
            p[3] = new SqlParameter("@InchargeId", RosterIncharge);
            p[4] = new SqlParameter("@Message", SqlDbType.VarChar, 250);
            p[4].Direction = ParameterDirection.Output;
            p[5] = new SqlParameter("@RosterId", RosterId);
            SqlHelper.ExecuteNonQuery(clsConnection.Connection, CommandType.StoredProcedure, "sp_UpdateEmpRosterMaster", p);
            return p[4].Value.ToString();
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetEmpRosterMasterDataByRosterId()
    {
        try
        {
            string str = "select * from tbl_EmpRosterMaster  where RosterId=" + this.RosterId;
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.Text, str);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetAllEmpRosterMasterData()
    {
        try
        {

            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.StoredProcedure, "sp_GetAllEmpRosterMasterData",null);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetAllRosterIds()
    {
        try 
        {
            string str = "select RosterId,RosterStartTime +'-'+ RosterEndTime as Shift from tbl_EmpRosterMaster";
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.Text,str);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }

    public string InsertEmpShiftsMaster()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[5];
            p[0] = new SqlParameter("@EmpId", EmpId);
            p[1] = new SqlParameter("@RosterId", RosterId);
            p[2] = new SqlParameter("@CustId", CustId);
            p[3] = new SqlParameter("@ServiceId", ServiceId);
           // p[4] = new SqlParameter("@EmpLoginDateTime", LoginTime);
           // p[5] = new SqlParameter("@EmpLogoffDateTime", LogoffTime);
            //p[4] = new SqlParameter("@NoOfClients", NoOfClients);
            p[4] = new SqlParameter("@Message", SqlDbType.VarChar, 250);
            p[4].Direction = ParameterDirection.Output;
            SqlHelper.ExecuteNonQuery(clsConnection.Connection, CommandType.StoredProcedure, "sp_InsertEmpShiftsMaster", p);
            return p[4].Value.ToString();
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetAllCustomers()
    {
        try
        {
            string strCust = "select CustomerId,Cust_Name from tbl_CustomerMaster";
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.Text, strCust);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }

    public DataSet GetServicesIdsByCustId()
    {
        try
        {
            SqlParameter[]p=new SqlParameter[1];
            p[0]=new SqlParameter ("@CustId",CustId);
            //string strCust = "select ServiceId,ServiceName  from tbl_ServicesMaster";
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.StoredProcedure,"sp_GetServicesByCustId",p);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetCallExecutes()
    {
        try
        {
            //string strCust = "select EmpId,Emp_FirstName  from tbl_Emp_Master ";

            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.StoredProcedure,"sp_GetCallExecutes",null);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetAllEmpShiftsMasterData()
    {
        try
        {
            //string strCust = "select EmpId,Emp_FirstName  from tbl_Emp_Master";
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.StoredProcedure, "sp_GetAllEmpShiftsMasterData",null);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetEmpByDate()
    {
        try
        {
            SqlParameter[]p=new  SqlParameter[3];
            p[0] = new SqlParameter("@StartDate", StartDate);
            p[1] = new SqlParameter("@EndDate", EndDate);
            p[2] = new SqlParameter("@Message", SqlDbType.VarChar, 250);
            p[2].Direction = ParameterDirection.Output;
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.StoredProcedure, "sp_GetEmployeesByDate", p);
            //p[2].Value.ToString();
        }
       catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public DataSet GetAllEmp()
    {
        try
        {
          return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.StoredProcedure, "sp_GetAllEmployees",null);
        }
       catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    
    }

    public static void LoginTime(DateTime LogTime, string EmpId)
    {
        try
        {
            SqlParameter[] p = new SqlParameter[2];
            p[0] = new SqlParameter("@LoginTime", LogTime);
            p[1]=new SqlParameter ("@EmpId",EmpId);

            SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.StoredProcedure, "sp_UpdateLoginTime",p);

        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }

    public static void LogOffTime(DateTime LogOffTime, string EmpId, int NoOfClients )
    {
        try
        {
            SqlParameter[] p = new SqlParameter[3];
            p[0] = new SqlParameter("@LogOffTime", LogOffTime);
            p[1] = new SqlParameter("@EmpId", EmpId);
            p[2] = new SqlParameter("@NoOfClients", NoOfClients);

            SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.StoredProcedure, "sp_UpdateLogOffTime", p);

        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    public string ChangePassword()
    {
        try
        {
            SqlParameter[] p = new SqlParameter[5];
            p[0] = new SqlParameter("@OldPwd", OldPwd);
            p[1] = new SqlParameter("@NewPwd", NewPwd);
            p[2] = new SqlParameter("@ConfirmPwd", ConfirmPwd);
            p[3] = new SqlParameter("@Message", SqlDbType.VarChar, 250);
            p[3].Direction = ParameterDirection.Output;
            p[4] = new SqlParameter("@EmpId", EmpId);
            SqlHelper.ExecuteNonQuery(clsConnection.Connection, CommandType.StoredProcedure, "sp_ChangePassword", p);
            return p[3].Value.ToString();
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
    //public string UpdateRequestStatus()
    //{
    //    try
    //    {
    //        SqlParameter[] p = new SqlParameter[3];
    //        p[0] = new SqlParameter("@ReqId", CustId);
    //        p[1] = new SqlParameter("@Status", Status);
    //        p[2] = new SqlParameter("@Message", SqlDbType.VarChar, 250);
    //        p[2].Direction = ParameterDirection.Output;
    //        return SqlHelper.ExecuteNonQuery(clsConnection.Connection, CommandType.StoredProcedure, "sp_UpdateRequestStatus", p);
    //    }
    //    catch (Exception ex)
    //    {
    //        throw new ArgumentException(ex.Message);
    //    }       
    //}
    public DataSet GetRequestCustByEmp()
    {
        try
        {
            string str = "select Cust_RequestingId from tbl_CallActivity where EmpAttendedId=" + this.EmpId + "and CallStatus='Pending'or CallStatus='Waiting For Acceptance'";
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.Text, str);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }   
    }
    public int UpdateRequestStatus()
    {
        try
        {
            string str = "update tbl_CallActivity set CallStatus='" + this.Status + "' where Cust_RequestingId=" + this.CustId;
            return SqlHelper.ExecuteNonQuery(clsConnection.Connection, CommandType.Text, str);

        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }   
    }
    public DataSet GetStatusByReqId()
    {
        try
        {
            string str = "select CallStatus from tbl_CallActivity where Cust_RequestingId=" + this.CustId;
            return SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.Text, str);
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        } 
    }
}
