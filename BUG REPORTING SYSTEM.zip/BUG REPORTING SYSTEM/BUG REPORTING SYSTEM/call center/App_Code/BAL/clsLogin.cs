﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using CallCenterManagement.DAL;
using System.Data.SqlClient;
/// <summary>
/// Summary description for clsLogin
/// </summary>
public class clsLogin:clsConnection
{
	public clsLogin()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public static  string UserName { get; set; }
    public static string Password { get; set; }
    public static string Role { get; set; }
    public static int EmpId { get; set; }

    public static string GetUserLogin(out int Id,out DateTime LoginDateTime)
    {
        try
        {
            SqlParameter[] p = new SqlParameter[5];

            p[0] = new SqlParameter("@UserName", UserName);
            p[0].SqlDbType = SqlDbType.VarChar;

            p[1] = new SqlParameter("@Password", Password );
            p[1].SqlDbType = SqlDbType.VarChar;

            p[2] = new SqlParameter("@Role", SqlDbType.VarChar, 20);
            p[2].Direction = ParameterDirection.Output;
            p[3] = new SqlParameter("@EmpId", SqlDbType.Int);
            p[3].Direction = ParameterDirection.Output;
            p[4] = new SqlParameter("@LoginDateTime", SqlDbType.DateTime);
            p[4].Direction = ParameterDirection.Output;
            SqlHelper.ExecuteNonQuery(clsConnection.Connection, CommandType.StoredProcedure, "sp_LoginChecking", p);
            Id = Convert.ToInt32(p[3].Value);
            LoginDateTime = Convert.ToDateTime(p[4].Value);
            return Role  = Convert.ToString(p[2].Value.ToString());
        }
        catch (Exception ex)
        {
            throw new ArgumentException(ex.Message);
        }
    }
}
