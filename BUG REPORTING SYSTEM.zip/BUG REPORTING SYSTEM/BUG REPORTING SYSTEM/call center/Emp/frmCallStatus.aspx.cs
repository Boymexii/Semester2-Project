﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Emp_frmCallStatus : System.Web.UI.Page
{
    int j;
    clsEmployee objEmp = new clsEmployee();
    protected void Page_Load(object sender, EventArgs e)
    {
        lblMsg.Text = "";
        if (!IsPostBack)
        {
            if (Session["UserId"] != null)
            {
                BindRequestCustId();
            }
        }
    }
    void BindRequestCustId()
    {
        try
        {
            objEmp.EmpId = Convert.ToInt32(Session["UserId"]);
            DataSet ds = objEmp.GetRequestCustByEmp();
            if (ds.Tables[0].Rows.Count > 0)
            {
                ddlReqId.DataSource = ds.Tables[0];
                ddlReqId.DataValueField = "Cust_RequestingId";
                ddlReqId.DataBind();
                ddlReqId.Items.Insert(0, "--Select RequestId--");
            }
            else
            {
                lblMsg.Text = "No Customers Available..";
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            objEmp.CustId = Convert.ToInt32(ddlReqId.SelectedItem.Value);
            objEmp.Status = ddlStatus.SelectedItem.Value;
            int i= objEmp.UpdateRequestStatus();
            
            if(i>0)
            {
                lblMsg.Text = "Status Updated Successfully..";
            }
            else
	        {
                lblMsg.Text="Status Not Updated. Try again";
	        }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void ddlReqId_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlReqId.SelectedIndex != 0)
            {
                objEmp.CustId = Convert.ToInt32(ddlReqId.SelectedItem.Value);
                DataSet ds = objEmp.GetStatusByReqId();
                DataRow dr = ds.Tables[0].Rows[0];
                if (ds.Tables[0].Rows.Count > 0)
                {
                    string str = dr["CallStatus"].ToString();

                    if (str != null)
                    {
                        for (int i = 0; i < ddlStatus.Items.Count; i++)
                        {
                            if (ddlStatus.Items[i].Text == str.ToString())
                            {
                                j = i;
                            }
                            ddlStatus.Items[i].Selected = false;
                        }
                        ddlStatus.Items[j].Selected = true;
                    }
                }
                else
                {
                    lblMsg.Text = "No data found ..";
                }
            }

            else
            {
                ddlStatus.SelectedIndex = 0;
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        lblMsg.Text = "";
        ddlReqId.SelectedIndex = 0;
        ddlStatus.SelectedIndex = 0;
    }
}
