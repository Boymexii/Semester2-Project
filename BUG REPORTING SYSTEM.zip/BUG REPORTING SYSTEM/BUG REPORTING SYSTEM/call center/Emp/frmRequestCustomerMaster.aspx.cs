﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

using Microsoft.VisualBasic.Devices;
using Microsoft.VisualBasic;
using System.Runtime.InteropServices;


public partial class Admin_frmRequestCustomerMaster : System.Web.UI.Page
{
    clsCustomer objReqCust = new clsCustomer();
    protected void Page_Load(object sender, EventArgs e)
    {
        lblMsg.Text = "";
        pnlCust.Visible = false;
        if (!IsPostBack)
        {
            if (Session["UserId"] != null)
            {
                //clsEmployee.LoginTime(DateTime.Now, Session["UserId"].ToString());
            }
        }
    }
   
    void ClearData()
    {
        try
        {
            txtAddress.Text = "";
            txtEmail.Text = "";
            txtRemarks.Text = "";
            txtName.Text = "";
            txtPhone.Text = "";
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
                lblMsg.Text = "";
                txtName.Focus();
                objReqCust.LoginDate =Convert.ToDateTime( Session["LoginDate"]);
                objReqCust.EmpId = Convert.ToInt32(Session["UserId"]);
                objReqCust.CustName = txtName.Text;
                objReqCust.Remarks = txtRemarks.Text;
                objReqCust.PhoneNo = txtPhone.Text;
                objReqCust.Address = txtAddress.Text;
                objReqCust.Email = txtEmail.Text;
                lblMsg.Text = objReqCust.InsertRequestCustomerMaster();
                //Session["NoofClients"] = Convert.ToInt32(Session["NoofClients"]) + 1;
                ClearData();              
        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        ClearData();
        
    }
    [DllImport("winmm.dll", EntryPoint = "mciSendStringA", CharSet = CharSet.Ansi, SetLastError = true, ExactSpelling = true)]
    private static extern int mciSendString(string lpstrCommand, string lpstrReturnString, int uReturnLength, int hwndCallback);

    protected void btnCall_Click(object sender, EventArgs e)
    {
        try
        {
            pnlCust.Visible = true;

            //mciSendString("open new Type waveaudio Alias recsound", "", 0, 0);
           // mciSendString("record recsound", "", 0, 0);

        }
        catch (Exception ex)
        {
            lblMsg.Text = ex.Message;
        }
    }
    //protected void btnStop_Click(object sender, EventArgs e)
    //{
    //    try
    //    {
    //         mciSendString("save recsound c:\\record.wav", "", 0, 0);
    //    mciSendString("close recsound ", "", 0, 0);

    //    Computer c = new Computer();
    //    c.Audio.Stop();
    //    }
    //    catch (Exception ex)
    //    {
    //        lblMsg.Text = ex.Message;
    //    }
       
    //}
    //protected void btnRead_Click(object sender, EventArgs e)
    //{
    //    try
    //    {
    //        Computer computer = new Computer();
    //    computer.Audio.Play("c:\\record.wav", AudioPlayMode.Background);
    //    }
    //    catch (Exception ex)
    //    {
    //        lblMsg.Text = ex.Message;
    //    }
       
        
    //}
}
