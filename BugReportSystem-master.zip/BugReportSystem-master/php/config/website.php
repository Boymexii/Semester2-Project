<?php
/**
 * Proj: WhiteCircle
 * User: CallumCarmicheal
 * Date: 05/04/2017
 * Time: 15:22
 */

//
// Defines the website path
//     This is required for the
//     pathing system
define ("WEB_ROOT", "http://localhost/WhiteCircle/");