<?php $_PAGE = ['Title' => "Manage Account - WhiteCircle"]; ?>

<?php require (LAYOUTS. "general.start.php"); ?>

	<section class="container" id="account">
		
		<h3>Password changed successful!</h3>
		<br>
		<p>Your password was successfully changed, you may now use your updated password.</p>
		
	</section>

<?php require (LAYOUTS. "general.end.php"); ?>
