<?php $_PAGE = ['Title' => "Bug Report - WhiteCircle"]; ?>

<?php require (LAYOUTS. "minimal.start.php"); ?>
	<section class="container" id="formSection">
		<h3>Submitted</h3>
		<p>Thank you for your bug report!</p>
	</section>
<?php require (LAYOUTS. "minimal.end.php"); ?>