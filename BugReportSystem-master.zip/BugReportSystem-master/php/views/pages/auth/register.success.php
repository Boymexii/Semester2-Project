<?php $_AUTH_PAGE = "Register"; ?>

<?php require (LAYOUTS. "auth/auth.start.php"); ?>
	
	
	<section class="container" id="formSection">
		
		<h3>Registration successful</h3>
		<br>
		<p>The registration was successful, please wait until your account has been enabled.</p>
		
	</section>


<?php require (LAYOUTS. "auth/auth.end.php"); ?>