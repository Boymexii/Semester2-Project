
	<br>
	<br>
	<?php /* Footer: */ require(VIEWS . "layouts/sections/footer.php"); ?>
</main>
	
<?php /* Scripts: */ require(VIEWS . "layouts/sections/scripts.php"); ?>

</body>
</html>