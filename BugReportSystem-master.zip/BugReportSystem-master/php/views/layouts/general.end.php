	<br>
	<br>
	
	<?php /* Footer: */ require(VIEWS. "layouts/sections/footer.php"); ?>
	
	<?php /* Modals: */ require(VIEWS. "layouts/sections/modals.php") ?>
</main>
	
<a href="#" id="back-to-top" title="Back to top">&uarr;</a>
	
<?php /* Scripts: */ require(VIEWS . "layouts/sections/scripts.php"); ?>

</body>
</html>