<footer class="footer">
	<section class="container">
		<p>
			Copyright © 2017 MaxLouisCreative. All Rights Reserved. <a href="https://whitecircle.maxlouiscreative.com/privacy-policy/">Privacy policy</a>
		</p>
	</section>
</footer>