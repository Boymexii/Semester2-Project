<meta charset="utf-8">
<meta name="viewport"       content="width=device-width, initial-scale=1">
<meta name="author"         content="">

<?php if(!empty($_PAGE['Description'])): ?>
	<meta name="description"    content="<?=$_PAGE['Description']?>">
<?php else: ?>
	<meta name="description"    content="">
<?php endif; ?>

<link rel="icon" href="https://i1.wp.com/whitecircle.maxlouiscreative.com/wp-content/uploads/2017/03/cropped-Circle-Logo.png?fit=32%2C32&#038;ssl=1" sizes="32x32" />
<link rel="icon" href="https://i1.wp.com/whitecircle.maxlouiscreative.com/wp-content/uploads/2017/03/cropped-Circle-Logo.png?fit=192%2C192&#038;ssl=1" sizes="192x192" />
<link rel="apple-touch-icon-precomposed" href="https://i1.wp.com/whitecircle.maxlouiscreative.com/wp-content/uploads/2017/03/cropped-Circle-Logo.png?fit=180%2C180&#038;ssl=1" />
<meta name="msapplication-TileImage" content="https://i1.wp.com/whitecircle.maxlouiscreative.com/wp-content/uploads/2017/03/cropped-Circle-Logo.png?fit=270%2C270&#038;ssl=1" />