
<div id="MODAL_PUBLIC_CONFIRM" class="modal fade" role="dialog">
	<div class="modal-dialog">
		<!-- Modal content-->
		<div class="modal-content">
			<div class="modal-header"><h4 class="modal-title" id="MODAL_PUBLIC_CONFIRM_TITLE"></h4></div>
			<div class="modal-body" id="MODAL_PUBLIC_CONFIRM_BODY"></div>
			<div class="modal-footer">
				<button type="button" id="MODAL_PUBLIC_CONFIRM_YES" class="button button-primary">Yes</button>
				<button type="button" id="MODAL_PUBLIC_CONFIRM_NO"  class="button button-outline">No</button>
			</div>
		</div>
	</div>
</div>

<div id="MODAL_PUBLIC_OKAY" class="modal fade" role="dialog">
	<div class="modal-dialog">
		<!-- Modal content-->
		<div class="modal-content">
			<div class="modal-header"><h4 class="modal-title" id="MODAL_PUBLIC_OKAY_TITLE"></h4></div>
			<div class="modal-body" id="MODAL_PUBLIC_OKAY_BODY"></div>
			<div class="modal-footer">
				<button type="button" id="MODAL_PUBLIC_OKAY_YES" class="button button-primary">Okay</button>
			</div>
		</div>
	</div>
</div>