<?php

// Load all our libs and config
require ("php/loader.inc.php");

// Redirect to Home.php
header("location: Home");
die("Redirecting to Home");