echo "Building BugRepGUI build $CIRCLE_BUILD_NUM ..."
mvn clean install